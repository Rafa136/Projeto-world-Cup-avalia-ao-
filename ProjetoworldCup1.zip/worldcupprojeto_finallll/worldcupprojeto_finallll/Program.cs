﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Projetomundial
{
    internal class Program
    {
        static void Main(string[] args)
        {



            string[] GrupoA = new string[2];
            string[] GrupoB = new string[2];
            string[] GrupoC = new string[2];
            string[] GrupoD = new string[2];
            string[] GrupoE = new string[2];
            string[] GrupoF = new string[2];
            string[] GrupoH = new string[2];
            string[] GrupoG = new string[2];


            string jQuartosfinal1 = "";
            string jQuartosfinal2 = "";
            string jQuartosfinal3 = "";
            string jQuartosfinal4 = "";
            string jQuartosfinal5 = "";
            string jQuartosfinal6 = "";
            string jQuartosfinal7 = "";
            string jQuartosfinal8= "";


            string jSemifinal1 = "";
            string jSemifinal2 = "";
            string jSemifinal3 = "";
            string jSemifinal4 = "";

            string jFinal1 = "";
            string jFinal2 = "";

            string jVencedor = "";

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-| MUNDIAL 2022 QATAR |-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/");
            Console.ResetColor();
            Console.WriteLine("\n  |----------------|   |----------------|   |----------------|   |---------------|   |--------------|");
            Console.WriteLine("  |   Grupo A      |   |    Grupo B     |   |   Grupo C      |   |   Grupo D     |   |   Grupo E    |");
            Console.WriteLine("  |----------------|   |----------------|   |----------------|   |---------------|   |--------------|");
            Console.WriteLine("  |  QATAR         |   |  ENGLAND       |   |  ARGENTINA     |   |   FRANÇA      |   |   ESPANHA    |");
            Console.WriteLine("  |                |   |                |   |                |   |               |   |              |");
            Console.WriteLine("  |  EQUADOR       |   |  IRAN          |   |  SAUDI ARABIA  |   |   AUSTRALIA   |   |   COSTA RICA |");
            Console.WriteLine("  |                |   |                |   |                |   |               |   |              |");
            Console.WriteLine("  |  SENEGAL       |   |  USA           |   |  MEXICO        |   |   DINAMARCA   |   |   ALEMANHA   |");
            Console.WriteLine("  |                |   |                |   |                |   |               |   |              |");
            Console.WriteLine("  |  NETHERLANDS   |   |  WALES         |   |  POLAND        |   |   TUNISIA     |   |   JAPÃO      |");
            Console.WriteLine("  |----------------|   |----------------|   |----------------|   |---------------|   |--------------|");
            Console.WriteLine("                                                                                                     ");
            Console.WriteLine("                      |----------------|   |----------------|   |----------------|   ");
            Console.WriteLine("                      |   Grupo F      |   |    Grupo G     |   |   Grupo H      |   ");
            Console.WriteLine("                      |----------------|   |----------------|   |----------------|   ");
            Console.WriteLine("                      |  BELGICA       |   |  BRASIL        |   | PORTUGAL       |   ");
            Console.WriteLine("                      |                |   |                |   |                |   ");
            Console.WriteLine("                      |  CANADA        |   |  SERVIA        |   | GAHNA          |   ");
            Console.WriteLine("                      |                |   |                |   |                |   ");
            Console.WriteLine("                      |  MARROCOS      |   |  SUIÇA         |   | URUGUAI        |   ");
            Console.WriteLine("                      |                |   |                |   |                |   ");
            Console.WriteLine("                      |  CROACIA       |   |  CAMARÕES      |   | COREIA DO SUL  |   ");
            Console.WriteLine("                      |----------------|   |----------------|   |----------------|   ");

            Console.WriteLine("\n\nAqui tens a tabela com todas as equipas que vão jogar no Mundial!");
            Console.WriteLine("Clica na tecla ENTER para prosseguir!");
            Console.ReadKey();
            Console.Clear();





            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("\n\n\n ------------------");
            Console.WriteLine(" |     GRUPO A    |");
            Console.WriteLine(" -----------------");
            Console.WriteLine(" |     Qatar      |");
            Console.WriteLine(" |    Equador     |");
            Console.WriteLine(" |    Senegal     |");
            Console.WriteLine(" |   Netherlands  |");
            Console.WriteLine(" ------------------");
            Console.ResetColor();



            Console.WriteLine("\n\n\nGrupo A 1º jogo:");
            string[] array1 = { "Senegal", "Qatar" };

            Random rnd1 = new Random();
            int Senegal = rnd1.Next(0,4);
            Random rnd2 = new Random();    
            int Qatar = rnd2.Next(0,4);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Senegal VS Qatar qual vai ser o vencedor:");
      
            if (Qatar > Senegal)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Qatar venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Qatar == Senegal)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Qatar < Senegal)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Senegal venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
           Console.WriteLine("Qatar: " + Qatar + " golos");
           Console.WriteLine("Senegal: " + Senegal+ " golos");
           Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");




            Console.WriteLine("\n\n\nGrupo A 2º jogo:");
            string[] array2 = { "Equador", "Netherlands" };
            
            Random rnd3 = new Random();
            int Equador = rnd3.Next(0, 5);
            Random rnd4 = new Random();
            int Netherlands = rnd4.Next(0, 4);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Equador VS Netherlands qual vai ser o vencedor:");

            if (Equador > Netherlands)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Equador venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Equador == Netherlands)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;


            }
            else if (Equador < Netherlands)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Netherlands venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Equador: " + Equador + " golos");
            Console.WriteLine("Netherlands: " + Netherlands + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");




            Console.WriteLine("\n\n\nGrupo A 3º jogo:");
            string[] array3 = { "Equador", "Qatar" };

            Random rnd5 = new Random();
            int Equador1 = rnd3.Next(0, 3);
            Random rnd6 = new Random();
            int Qatar1 = rnd4.Next(0, 3);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Equador VS Qatar qual vai ser o vencedor:");

            if (Equador > Qatar1)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Equador venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Equador == Qatar1)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Equador < Qatar1)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Qatar venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Equador: " + Equador + " golos");
            Console.WriteLine("Qatar: " + Qatar1 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");









            Console.WriteLine("\n\n\nGrupo A 4º jogo:");
            string[] array4 = { "Qatar", "Netherlands" };

            Random rnd7 = new Random();
            int Netherlands1 = rnd3.Next(0, 6);
            Random rnd8 = new Random();
            int Senegal1 = rnd4.Next(0, 3);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Netherlands VS Senegal qual vai ser o vencedor:");

            if (Netherlands1 > Senegal1)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Netherlands venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Netherlands1 == Senegal1)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Netherlands1 < Senegal1)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Senegal venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Netherlands: " + Netherlands1 + " golos");
            Console.WriteLine("Senegal: "  + Senegal1 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");






            Console.WriteLine("\n\n\nGrupo A 5º jogo:");
            string[] array = { "Senegal", "Equador" };

            Random rnd9 = new Random();
            int Senegal2 = rnd1.Next(0, 4);
            Random rnd10 = new Random();
            int Equador2 = rnd2.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Senegal VS Equador qual vai ser o vencedor:");

            if (Equador > Senegal)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Equador venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Equador == Senegal)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Equador < Senegal)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Senegal venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Equador: " + Equador2 + " golos");
            Console.WriteLine("Senegal: " + Senegal2 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");






            Console.WriteLine("\n\n\nGrupo A 6º jogo:");
            string[] array99 = { "Qatar", "Netherlands" };

            Random rnd18 = new Random();
            int Netherlands18 = rnd3.Next(0,5);
            Random rnd = new Random();
            int Qatar18 = rnd4.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Netherlands VS Qatar qual vai ser o vencedor:");

            if (Netherlands1 > Qatar1)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Netherlands venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Netherlands1 == Qatar1)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Netherlands1 < Qatar1)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Qatar venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Netherlands: " + Qatar1 + " golos");
            Console.WriteLine("Qatar: " + Qatar1 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");

            int gQa = Qatar + Qatar1 + Qatar18;
            int gEQ = Senegal + Senegal1 + Senegal2;
            int gSe = Equador + Equador1 + Equador2;
            int gNt = Netherlands + Netherlands1 + Netherlands18;

            int vQa = 0;
            int vEQ = 0;
            int vNt = 0;
            int vSe = 0;

            int eQa = 0;
            int eEQ = 0;
            int eNt = 0;
            int eSe = 0;

            int dQa = 0;
            int dEQ = 0;
            int dNt = 0;
            int dSe = 0;

            int pQa = 0;
            int pEq = 0;
            int pNt = 0;
            int pSe = 0;

            if (Qatar > Senegal)
            {
                vQa++;
                dSe++;

            }
            else if (Qatar == Senegal)
            {
                eQa++;
                eSe++;
            }
            else if (Qatar < Senegal)
            {
                vSe++;
                dQa++;
            }
            
            
            
            
            
            if (Equador > Netherlands)
            {
                vEQ++;
                dNt++;
            }
            else if (Equador == Netherlands)
            {
                eEQ++;
                eNt++;

            }
            else if (Equador < Netherlands)
            {
                vNt++;
                dEQ++;
            }
            



            if (Qatar1 > Netherlands1)
            {
                vQa++;
                dNt++;
            }
            else if (Qatar1 == Netherlands1)
            {
                eQa++;
                eNt++;
            }
            else if (Qatar1 < Netherlands18)
            {
                vNt++;
                dQa++;

            }
           



            if (Netherlands18 > Senegal1)
            {
                vNt++;
                dSe++;
            }
            else if (Netherlands18 == Senegal1)
            {
                eNt++;
                eSe++;
            }
            else if (Netherlands18 < Senegal1)
            {
                vSe++;
                dNt++;

            }
            



            if (Equador1 > Senegal2)
            {
                vEQ++;
                dSe++;
                
            }
            else if (Equador1 == Senegal2)
            {
                eEQ++;
                eSe++;
            }
            else if (Equador1 < Senegal2)
            {
                vSe++;
                dEQ++;
            }
            



            if (Qatar18 > Equador)
            {
                vQa++;
                dEQ++;
            }
            else if (Qatar18 == Equador)
            {
                eEQ++;
                eQa++;
            }
            else if (Qatar18 < Equador)
            {
                vEQ++;
                dQa++;
            }
           



            if (Qatar > Senegal)
            {
                pQa += 3;
                pSe += 3;
            }
            else if (Qatar == Senegal)
            {
                pQa++;
                pSe++;
            }
            else if (Qatar < Senegal)
            {
                pSe += 3;
                pQa += 3;
            }
           



            if (Equador > Netherlands)
            {
                pEq += 3;
                pNt += 3;
            }
            else if (Equador == Netherlands)
            {
                pEq++;
                pNt++;

            }
            else if (Equador < Netherlands)
            {
                pNt += 3;
                pEq += 3;
            }
            



            
            if (Qatar1 > Netherlands1)
            {
                pQa += 3;
                pNt += 3;
            }
            else if (Qatar1 == Netherlands1)
            {
                pQa++;
                pNt++;
            }
            else if (Qatar1 < Netherlands1)
            {
                pNt += 3;
                pQa += 3;

            }
            



            if (Netherlands18 > Senegal1)
            {
                pNt += 3;
                pSe += 3;
            }
            else if (Netherlands18 == Senegal1)
            {
                pNt++;
                pSe++;
            }
            else if (Netherlands18 < Senegal1)
            {
                pSe += 3;
                pNt += 3;

            }
           



            if (Equador1 > Senegal2)
            {
                pEq += 3;
                pSe += 3;
            }
            else if (Equador1 == Senegal2)
            {
                pEq++;
                pSe++;
            }
            else if (Equador1 < Senegal2)
            {
                pSe += 3;
                pEq += 3;
            }
            



            if (Qatar18 > Equador2)
            {
                pQa += 3;
                pEq += 3;
            }
            else if (Qatar18 == Equador2)
            {
                pEq++;
                pQa++;
            }
            else if (Qatar18 < Equador2)
            {
                pEq += 3;
                pQa += 3;
 
            }


            Console.WriteLine("\n\nClassificações do Grupo A:");

            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação do Qatar:");
            Console.WriteLine("Vitorias: " + vQa + "");
            Console.WriteLine("Empates:"+ eQa   +"");
            Console.WriteLine("Derrotas: " + dQa + ""); 
            Console.WriteLine("Golos Marcados: " +gQa + " ");
            Console.WriteLine("Pontos: " + pQa+" ");
            Console.WriteLine("___________________________");


            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação do Equador:");
            Console.WriteLine("Vitorias: " + vEQ + "");
            Console.WriteLine("Empates:" + eEQ + "");
            Console.WriteLine("Derrotas: " + dEQ + "");
            Console.WriteLine("Golos Marcados: " + gEQ + " ");
            Console.WriteLine("Pontos: " + pEq + " ");
            Console.WriteLine("___________________________");



            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação do Senegal:");
            Console.WriteLine("Vitorias: " + vSe + "");
            Console.WriteLine("Empates:" + eSe + "");
            Console.WriteLine("Derrotas: " + dSe + "");
            Console.WriteLine("Golos Marcados: " + gSe + " ");
            Console.WriteLine("Pontos: " + pSe + " ");
            Console.WriteLine("___________________________");


            
            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação do Netherlands:");
            Console.WriteLine("Vitorias: " + vNt + "");
            Console.WriteLine("Empates:" + eNt + "");
            Console.WriteLine("Derrotas: " + dNt + "");
            Console.WriteLine("Golos Marcados: " + gNt + " ");
            Console.WriteLine("Pontos: " + pNt + " ");
            Console.WriteLine("___________________________");





            Console.WriteLine("\n\nClica na tecla ENTER para continuar no proximo Grupo!");
            Console.ReadKey();
            Console.Clear();





            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("\n  ------------------");
            Console.WriteLine(" |     GRUPO B      |");
            Console.WriteLine(" |------------------|");
            Console.WriteLine(" |    Inglaterra    |");
            Console.WriteLine(" |  Estados Unidos  |");
            Console.WriteLine(" |      Irão        |");
            Console.WriteLine(" |   País de Gales  |");
            Console.WriteLine(" |------------------|");
            Console.ResetColor();


            Console.WriteLine("Neste grupo tem uma equipa que é candidata a vitoria do Torneio  , a equipa é a Inglaterra porque tem o melhor defesa do mundo Harry Maguire ");
            Console.WriteLine("Neste grupo a um jogador em destque na equipa do Irão , ter atenção no melhor mergulhador do mundo Mehdi Taremi");




            Console.WriteLine("\n\n\nGrupo B 1º jogo:");
            string[] array5 = { "Inglaterra", "Estados Unidos" };

            Random rnd19 = new Random();
            int Inglaterra = rnd1.Next(0, 2);
            Random rnd20 = new Random();
            int EstadosUnidos = rnd2.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Inglaterra VS Estados Unidos qual vai ser o vencedor:");

            if (Inglaterra > EstadosUnidos)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Inglaterra venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Inglaterra == EstadosUnidos)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Inglaterra < EstadosUnidos)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Estados Unidos venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Inglaterra: " + Inglaterra + " golos");
            Console.WriteLine("Estados Unidos : " + EstadosUnidos + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");





            Console.WriteLine("\n\nGrupo B 2º jogo:");
            string[] array101 = { "Inglaterra", " Irão " };

            Random rnd25 = new Random();
            int Inglaterra1 = rnd3.Next(0, 4);
            Random rnd14 = new Random();
            int Irão1 = rnd4.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Inglaterra VS Irão qual vai ser o vencedor:");

            if (Inglaterra > Irão1)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Inglaterra venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Inglaterra == Irão1)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Inglaterra < Irão1)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Irão venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Inglaterra: " + Inglaterra + " golos");
            Console.WriteLine("Irão : " + Irão1 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");




            
            Console.WriteLine("\n\n\nGrupo B 3º jogo:");
            string[] array1012 = { "Estados Unidos", " Irão " };

            Random rnd35 = new Random();
            int Estados_Unidos123 = rnd3.Next(0, 4);
            Random rnd112 = new Random();
            int Irão112 = rnd4.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("Jogo Estados Unidos  VS Irão quem vai ser o vencedor:");

            if (Estados_Unidos123 > Irão112)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(" Estados Unidos venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Estados_Unidos123 == Irão112)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Estados_Unidos123 < Irão112)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Irão venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Estados Unidos : " + Estados_Unidos123 + " golos");
            Console.WriteLine("Irão : " + Irão1 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");









            Console.WriteLine("\n\n\nGrupo B 4º jogo:");
            string[] array7 = { "Inglaterra", "Pais de Gales" };

            Random rnd26 = new Random();
            int Inglaterra2 = rnd3.Next(0, 4);
            Random rnd27 = new Random();
            int PaisGales = rnd4.Next(0, 4);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Inglaterra VS País de Gales qual vai ser o vencedor:");

            if (Inglaterra2 > PaisGales)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Inglaterra venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Inglaterra2 == PaisGales)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Inglaterra2 < PaisGales)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Pais Gales venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Inglaterra: " + Inglaterra2 + " golos");
            Console.WriteLine("País de Gales: " + PaisGales + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");






            Console.WriteLine("\n\n\nGrupo B 5º jogo:");
            string[] array8 = { "Estados Unidos", "País de Gales" };

            Random rnd28 = new Random();
            int EstadosUnidos2 = rnd1.Next(0, 4);
            Random rnd29 = new Random();
            int PaisGales2 = rnd2.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Estados Unidos VS Irão qual vai ser o vencedor:");

            if (EstadosUnidos2 > PaisGales2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Estados Unidos venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (EstadosUnidos2 == PaisGales2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (EstadosUnidos2 < PaisGales2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("País de Gales venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Estados Unidos: " + EstadosUnidos2 + " golos");
            Console.WriteLine("País de Gales: " + PaisGales2 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");






            Console.WriteLine("\n\n\nGrupo B 6º jogo:");
            string[] array9 = { "País de Gales", "Irão" };

            Random rnd30 = new Random();
            int PaisGales3 = rnd3.Next(0, 4);
            Random rnd31 = new Random();
            int Irao3 = rnd4.Next(0, 4);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: País de Gales VS Irão qual vai ser o vencedor:");

            if (PaisGales3 > Irao3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("País de Gales venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (PaisGales3 == Irao3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (PaisGales3 < Irao3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Irão venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("País de Gales: " + PaisGales3 + " golos");
            Console.WriteLine("Irão: " + Irao3 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");





            int gIg = Inglaterra + Inglaterra + Inglaterra;
            int gIr = Irão1 + Irão112 + Irao3;
            int gPg = PaisGales + PaisGales2 + PaisGales3;
            int gEu = EstadosUnidos + EstadosUnidos2 + Estados_Unidos123;

            int vIg = 0;
            int vIr = 0;
            int vPg = 0;
            int vEu = 0;

            int eIg = 0;
            int eIr = 0;
            int ePg = 0;
            int eEu = 0;

            int dIg = 0;
            int dIr = 0;
            int dPg = 0;
            int dEu = 0;

            int pIg = 0;
            int pIr = 0;
            int pPg = 0;
            int pEu = 0;

            if (Inglaterra > EstadosUnidos)
            {
                vIg++;
                dEu++;
            }
            else if (Inglaterra == EstadosUnidos)
            {
                eIg++;
                eEu++;

            }
            else if (Inglaterra < EstadosUnidos)
            {
                vEu++;
                dIg++;

            }
            /*-------------------------------------*/
            
            if (Irão1 > PaisGales)
            {
                vIr++;
                dPg++;

            }
            else if (Irão1 == PaisGales)
            {
                eIr++;
                ePg++;
            }
            else if (Irão1 < PaisGales)
            {
                vPg++;
                dIr++;

            }
            /*-------------------------------------*/
            if (Irão112 > EstadosUnidos2)
            {
                vIr++;
                dEu++;

            }
            else if (Irão112 == EstadosUnidos2)
            {
                eIr++;
                eEu++;

            }
            else if (Irão112 < EstadosUnidos2)
            {
                vEu++;
                dIr++;

            }
            /*-------------------------------------*/
            if (Inglaterra1 > PaisGales2)
            {
                vIg++;
                dPg++;
            }
            else if (Inglaterra1 == PaisGales2)
            {
                eIg++;
                ePg++;

            }
            else if (Inglaterra1 < PaisGales2)
            {
                vPg++;
                dIg++;

            }

            /*-------------------------------------*/
            if (PaisGales3 > Estados_Unidos123)
            {
                vPg++;
                dEu++;
            }
            else if (PaisGales3 == Estados_Unidos123)
            {
                ePg++;
                eEu++;

            }
            else if (PaisGales3 < Estados_Unidos123)
            {
                vEu++;
                dPg++;

            }
            /*-------------------------------------*/
            if (Inglaterra2 > Irão112)
            {
                vIg++;
                dIr++;

            }
            else if (Inglaterra2 == Irão112)
            {
                eIg++;
                eIr++;

            }
            else if (Inglaterra2 < Irão112)
            {
                vIr++;
                dIg++;

            }
            /*-------------------------------------*/
            /*-------------------------------------*/

            if (Inglaterra2 > Estados_Unidos123)
            {
                pIg += 3;
            }
            else if (Inglaterra2 == Estados_Unidos123)
            {
                pIg++;
                pEu++;

            }
            else if (Inglaterra2 < Estados_Unidos123)
            {

                pEu += 3;
            }
            /*-------------------------------------*/
            
            
            
            if (Irao3 > PaisGales3)
            {
                pIr += 3;

            }
            else if (Irao3 == PaisGales3)
            {
                pIr++;
                pPg++;
            }
            else if (Irao3 < PaisGales3)
            {
                pPg += 3;

            }
            /*-------------------------------------*/
            if (Irao3 > Estados_Unidos123)
            {
                pIr += 3;

            }
            else if (Irao3 == Estados_Unidos123)
            {
                pIr++;
                pEu++;

            }
            else if (Irao3 < Estados_Unidos123)
            {
                pEu += 3;

            }
            /*-------------------------------------*/
            if (Inglaterra2 > PaisGales3)
            {
                pIg += 3;
            }
            else if (Inglaterra2 == PaisGales3)
            {
                pIg++;
                pPg++;

            }
            else if (Inglaterra2 < PaisGales3)
            {
                pPg += 3;

            }
            /*-------------------------------------*/
            if (PaisGales > EstadosUnidos)
            {
                pPg += 3;
            }
            else if (PaisGales == EstadosUnidos)
            {
                pPg++;
                pEu++;

            }
            else if (PaisGales < EstadosUnidos)
            {
                pEu += 3;

            }
            /*-------------------------------------*/
            if (Inglaterra2 > Irão1)
            {
                pIg += 3;

            }
            else if (Inglaterra2 == Irão1)
            {
                pIg++;
                pIr++;

            }
            else if (Inglaterra2 < Irão1)
            {
                pIr += 3;

            }


            Console.WriteLine("\n\nClassificações do Grupo B:");


            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação do Inglaterra:");
            Console.WriteLine("Vitorias: " + vIg + "");
            Console.WriteLine("Empates:" + eIg + "");
            Console.WriteLine("Derrotas: " + dIg + "");
            Console.WriteLine("Golos Marcados: " + gIg + " ");
            Console.WriteLine("Pontos: " + pIg + " ");
            Console.WriteLine("___________________________");


            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação do Estados Unidos:");
            Console.WriteLine("Vitorias: " + vEu + "");
            Console.WriteLine("Empates:" + eEu + "");
            Console.WriteLine("Derrotas: " + dEu + "");
            Console.WriteLine("Golos Marcados: " + gEu + " ");
            Console.WriteLine("Pontos: " + pEu + " ");
            Console.WriteLine("___________________________");



            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação do Irão:");
            Console.WriteLine("Vitorias: " + vIr + "");
            Console.WriteLine("Empates:" + eIr + "");
            Console.WriteLine("Derrotas: " + dIr + "");
            Console.WriteLine("Golos Marcados: " + gIr + " ");
            Console.WriteLine("Pontos: " + pIr + " ");
            Console.WriteLine("___________________________");



            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação do País de Gales:");
            Console.WriteLine("Vitorias: " + vPg + "");
            Console.WriteLine("Empates:" + ePg + "");
            Console.WriteLine("Derrotas: " + dPg + "");
            Console.WriteLine("Golos Marcados: " + gPg + " ");
            Console.WriteLine("Pontos: " + pPg + " ");
            Console.WriteLine("___________________________");




            Console.WriteLine("\n\nClica na tecla ENTER para continuar no proximo Grupo!");
            Console.ReadKey();
            Console.Clear();






            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("\n  ------------------");
            Console.WriteLine(" |     GRUPO C      |");
            Console.WriteLine(" |------------------|");
            Console.WriteLine(" |     Argentina    |");
            Console.WriteLine(" |  Arabia Saudita  |");
            Console.WriteLine(" |      México      |");
            Console.WriteLine(" |      Polonia     |");
            Console.WriteLine(" |------------------|");
            Console.ResetColor();




            Console.WriteLine("\n\n\nGrupo C 1º jogo:");
            string[] array6 = { "Argentina", "Arabia Saudita" };

            Random rnd32 = new Random();
            int Argentina = rnd1.Next(0, 6);
            Random rnd33 = new Random();
            int ArabiaSaudita = rnd2.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Argentina VS Arabia Saudita qual vai ser o vencedor:");

            if (Argentina > ArabiaSaudita)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Argentina venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Argentina == ArabiaSaudita)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Argentina < ArabiaSaudita)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Arabia Saudita venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Argentina: " + Argentina + " golos");
            Console.WriteLine("Arabia Saudita: " + ArabiaSaudita + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");





            Console.WriteLine("\n\nGrupo C 2 jogo:");
            string[] array10 = { "México", " Polónia " };

            Random rnd34 = new Random();
            int Mexico = rnd3.Next(0, 4);
            Random rnd36 = new Random();
            int Polonia = rnd4.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: México VS Polónia qual vai ser o vencedor:");

            if (Mexico > Polonia)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("México venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Mexico == Polonia)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Mexico < Polonia)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Polónia venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("México: " + Mexico + " golos");
            Console.WriteLine("Polónia: " + Polonia + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");





            Console.WriteLine("\n\n\nGrupo C 3º jogo:");
            string[] array11 = { "Polónia", " Arabia Saudita" };

            Random rnd37 = new Random();
            int Polonia2 = rnd3.Next(0, 4);
            Random rnd38 = new Random();
            int ArabiaSaudita2 = rnd4.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("Jogo Polonia  VS Arabia Saudita quem vai ser o vencedor:");

            if (Polonia2 > ArabiaSaudita2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(" Polónia venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Polonia2 == ArabiaSaudita2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;


            }
            else if (Polonia2 < ArabiaSaudita2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Arabia Saudita venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Polónia: " + Polonia2 + " golos");
            Console.WriteLine("Arabia Saudita: " + ArabiaSaudita2 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");









            Console.WriteLine("\n\n\nGrupo C 4º jogo:");
            string[] array12 = { "Argentina", "México" };

            Random rnd39 = new Random();
            int Argentina2 = rnd3.Next(0, 4);
            Random rnd40 = new Random();
            int Mexico2 = rnd4.Next(0, 3);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Argentina VS México qual vai ser o vencedor:");

            if (Argentina2 > Mexico2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Argentina venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Argentina2 == Mexico2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Argentina2 < Mexico2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("México venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Argentina: " + Argentina2 + " golos");
            Console.WriteLine("México: " + Mexico2 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");






            Console.WriteLine("\n\n\nGrupo C 5º jogo:");
            string[] array13 = { "Polónia", "Argentina" };

            Random rnd41 = new Random();
            int Polonia3 = rnd1.Next(0, 2);
            Random rnd42 = new Random();
            int Argentina3 = rnd2.Next(0, 4);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Polónia VS Argentina vai ser o vencedor:");

            if (Polonia3 > Argentina3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Polónia venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Polonia3 == Argentina3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Polonia3 < Argentina3)
            {
                Console.Write("Resultado: ");
                Console.Write("Argentina venceu!\n");

            }
            Console.WriteLine("Polónia: " + Polonia3 + " golos");
            Console.WriteLine("Argentina: " + Argentina3 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");






            Console.WriteLine("\n\n\nGrupo C 6º jogo:");
            string[] array14 = { "Arabia Saudita", "México" };

            Random rnd43 = new Random();
            int ArabiaSaudita3 = rnd3.Next(0, 4);
            Random rnd44 = new Random();
            int Mexico3 = rnd4.Next(0, 4);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Arabia Saudita VS México qual vai ser o vencedor:");

            if (ArabiaSaudita3 > Mexico3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Arabia Saudita venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (ArabiaSaudita3 == Mexico3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (ArabiaSaudita3 < Mexico3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("México venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Arabia Saudita: " + ArabiaSaudita3 + " golos");
            Console.WriteLine("México: " + Mexico3 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");


            int gAr = ArabiaSaudita + ArabiaSaudita2 + ArabiaSaudita3 ;
            int gMe = Mexico + Mexico2 + Mexico3;
            int gPo = Polonia3 + Polonia3 + Polonia3;
            int gAg = Argentina + Argentina2 + Argentina3;

            int vAr = 0;
            int vMe = 0;
            int vPo = 0;
            int vAg = 0;

            int eAr = 0;
            int eMe = 0;
            int ePo = 0;
            int eAg = 0;

            int dAr = 0;
            int dMe = 0;
            int dPo = 0;
            int dAg = 0;

            int pAr = 0;
            int pMe = 0;
            int pPo = 0;
            int pAg = 0;

            if (Argentina > ArabiaSaudita)
            {
                vAg++;
                dAr++;
            }
            else if (Argentina == ArabiaSaudita)
            {
                eAg++;
                eAr++;

            }
            else if (Argentina < ArabiaSaudita)
            {
                vAr++;
                dAg++;

            }
            /*-------------------------------------*/
            if (Mexico > Polonia)
            {
                vMe++;
                dPo++;
            }
            else if (Mexico == Polonia)
            {
                eMe++;
                ePo++;
            }
            else if (Mexico < Polonia)
            {
                vPo++;
                dMe++;
            }
            /*-------------------------------------*/
            if (Polonia2 > ArabiaSaudita2)
            {
                vPo++;
                dAr++;
            }
            else if (Polonia2 == ArabiaSaudita2)
            {
                ePo++;
                eAr++;
            }
            else if (Polonia2 < ArabiaSaudita2)
            {
                vAr++;
                dPo++;

            }

            /*-------------------------------------*/
            if (Argentina2 > Mexico2)
            {
                vAg++;
                dMe++;
            }
            else if (Argentina2 == Mexico2)
            {
                eAg++;
                eMe++;
            }
            else if (Argentina2 < Mexico2)
            {
                vMe++;
                dAr++;
            }
            /*-------------------------------------*/
            if (Argentina3 > Polonia3)
            {
                vAg++;
                dPo++;
            }
            else if (Argentina3 == Polonia3)
            {
                eAg++;
                ePo++;

            }
            else if (Argentina3 < Polonia3)
            {
                vPo++;
                dAg++;


            }
            /*-------------------------------------*/
            if (ArabiaSaudita3 > Mexico3)
            {
                vAr++;
                dMe++;
            }
            else if (ArabiaSaudita3 == Mexico3)
            {
                eMe++;
                eAr++;

            }
            else if (ArabiaSaudita3 < Mexico3)
            {
                vMe++;
                dAr++;

            }
            /*-------------------------------------*/
            /*-------------------------------------*/

            if (Argentina > ArabiaSaudita)
            {
                pAg += 3;
            }
            else if (Argentina == ArabiaSaudita)
            {
                pAg++;
                pAr++;

            }
            else if (Argentina < ArabiaSaudita)
            {

                pAr += 3;

            }
            /*-------------------------------------*/
            if (Mexico > Polonia)
            {
                pMe += 3;
            }
            else if (Mexico == Polonia)
            {
                pMe++;
                pPo++;
            }
            else if (Mexico < Polonia)
            {
                pPo += 3;
            }
            /*-------------------------------------*/
            if (Polonia2 > ArabiaSaudita2)
            {
                pPo += 3;
            }
            else if (Polonia2 == ArabiaSaudita2)
            {
                pPo++;
                pAr++;
            }
            else if (Polonia2 < ArabiaSaudita2)
            {
                pAr += 3;

            }
            /*-------------------------------------*/
            if (ArabiaSaudita2 > Mexico2)
            {
                pAg += 3;
            }
            else if (ArabiaSaudita2 == Mexico2)
            {
                pAg++;
                pMe++;
            }
            else if (ArabiaSaudita2 < Mexico2)
            {
                pMe += 3;
            }
            /*-------------------------------------*/
            if (Argentina2 > Polonia2)
            {
                pAg += 3;

            }
            else if (Argentina2 == Polonia2)
            {
                pAg++;
                pPo++;

            }
            else if (Argentina2 < Polonia2)
            {
                pPo += 3;

            }
            /*-------------------------------------*/
            if (ArabiaSaudita3 > Mexico3)
            {
                pAr += 3;
            }
            else if (ArabiaSaudita3 == Mexico3)
            {
                pMe++;
                pAr++;

            }
            else if (ArabiaSaudita3 < Mexico3)
            {
                pMe += 3;

            }


            Console.WriteLine("\n\nClassificações do Grupo C:");

            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação do México:");
            Console.WriteLine("Vitorias: " + vMe + "");
            Console.WriteLine("Empates:" + eMe + "");
            Console.WriteLine("Derrotas: " + dMe + "");
            Console.WriteLine("Golos Marcados: " + gMe + " ");
            Console.WriteLine("Pontos: " + pMe + " ");
            Console.WriteLine("___________________________");


            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação do Polónia:");
            Console.WriteLine("Vitorias: " + vPo + "");
            Console.WriteLine("Empates:" + ePo + "");
            Console.WriteLine("Derrotas: " + dPo + "");
            Console.WriteLine("Golos Marcados: " + gPo + " ");
            Console.WriteLine("Pontos: " + pPo + " ");
            Console.WriteLine("___________________________");



            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação do Argentina:");
            Console.WriteLine("Vitorias: " + vAg + "");
            Console.WriteLine("Empates:" + eAg + "");
            Console.WriteLine("Derrotas: " + dAg + "");
            Console.WriteLine("Golos Marcados: " + gAg + " ");
            Console.WriteLine("Pontos: " + pAg + " ");
            Console.WriteLine("___________________________");



            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação do Arábia Saudita:");
            Console.WriteLine("Vitorias: " + vAr + "");
            Console.WriteLine("Empates:" + eAr + "");
            Console.WriteLine("Derrotas: " + dAr + "");
            Console.WriteLine("Golos Marcados: " + gAr + " ");
            Console.WriteLine("Pontos: " + pAr + " ");
            Console.WriteLine("___________________________");



            Console.WriteLine("\n\nClica na tecla ENTER para continuar no proximo Grupo!");
            Console.ReadKey();
            Console.Clear();





            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("\n  ------------------");
            Console.WriteLine(" |     GRUPO D      |");
            Console.WriteLine(" |------------------|");
            Console.WriteLine(" |      Dinamarca   |");
            Console.WriteLine(" |      Tunisia     |");
            Console.WriteLine(" |       França     |");
            Console.WriteLine(" |     Australia    |");
            Console.WriteLine(" |------------------|");
            Console.ResetColor();   




            Console.WriteLine("\n\n\nGrupo D 1º jogo:");
            string[] array15 = { "Dinamarca", "Tunisia" };

            Random rnd45 = new Random();
            int Dinamarca = rnd1.Next(0, 1);
            Random rnd46 = new Random();
            int Tunisia = rnd2.Next(0, 1);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Dinamarca VS Tunisia qual vai ser o vencedor:");

            if (Dinamarca > Tunisia)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Dinamarca venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Dinamarca == Tunisia)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Dinamarca < Tunisia)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Tunisia venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Dinamarca: " + Dinamarca + " golos");
            Console.WriteLine("Tunisia: " + Tunisia + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");





            Console.WriteLine("\n\nGrupo D 2 jogo:");
            string[] array16 = { "França", "Austrália" };

            Random rnd47 = new Random();
            int França = rnd3.Next(0, 4);
            Random rnd48 = new Random();
            int Australia = rnd4.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: França VS Austrália qual vai ser o vencedor:");

            if (França > Australia)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("França venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (França == Australia)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (França < Australia)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Austrália venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            Console.WriteLine("França: " + França + " golos");
            Console.WriteLine("Austrália: " + Australia + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");





            Console.WriteLine("\n\n\nGrupo D 3º jogo:");
            string[] array17 = { "Tunisia", " Austrália" };

            Random rnd49 = new Random();
            int Tunisia2 = rnd3.Next(0, 4);
            Random rnd50 = new Random();
            int Australia2 = rnd4.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("Jogo Tunisia VS Austrália quem vai ser o vencedor:");

            if (Tunisia2 > Australia2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Tunisia venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Tunisia2 == Australia2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Tunisia2 < Australia2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Austrália venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Tunisia: " + Tunisia2 + " golos");
            Console.WriteLine("Austrália: " + Australia2 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");









            Console.WriteLine("\n\n\nGrupo D 4º jogo:");
            string[] array18 = { "França", "Dinamarca" };

            Random rnd51 = new Random();
            int França2 = rnd3.Next(0, 2);
            Random rnd52 = new Random();
            int Dinamarca2 = rnd4.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: França VS Dinamarca qual vai ser o vencedor:");

            if (França2 > Dinamarca2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("França venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (França2 == Dinamarca2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (França2 < Dinamarca2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Dinamarca venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("França:" + França2 + " golos");
            Console.WriteLine("Dinamarca:" + Dinamarca2 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");






            Console.WriteLine("\n\n\nGrupo D 5º jogo:");
            string[] array19 = { "Austrália", "Dinamarca" };

            Random rnd53 = new Random();
            int Australia3 = rnd1.Next(0, 2);
            Random rnd54= new Random();
            int Dinamarca3 = rnd2.Next(0, 4);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Austrália VS Dinamarca vai ser o vencedor:");

            if (Australia3 > Dinamarca3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Austrália venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Australia3 == Dinamarca3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Australia3 < Dinamarca3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Dinamarca venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Austrália:" + Australia3 + " golos");
            Console.WriteLine("Dinamarca:" + Dinamarca3 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");






            Console.WriteLine("\n\n\nGrupo D 6º jogo:");
            string[] array20 = { "Tunisia", "França" };

            Random rnd55 = new Random();
            int Tunisia3 = rnd3.Next(0, 1);
            Random rnd56 = new Random();
            int França3  = rnd4.Next(0, 1);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Tunisia Saudita VS França qual vai ser o vencedor:");

            if (Tunisia3 > França3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Tunisia venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Tunisia3 == França3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Tunisia3 < França3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Tunisia venceu!\n");
                Console.ForegroundColor = ConsoleColor.Green;

            }
            Console.WriteLine("Tunisia:" + Tunisia3 + " golos");
            Console.WriteLine("França:" + França3 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");


            int gDi = Dinamarca + Dinamarca2 + Dinamarca3;
            int gAu = Australia + Australia2 + Australia3;
            int gTu = Tunisia + Tunisia2 + Tunisia3;
            int gFr = França + França2 + França3;

            int vDi = 0;
            int vAu = 0;
            int vTu = 0;
            int vFr = 0;

            int eDi = 0;
            int eAu = 0;
            int eTu = 0;
            int eFr = 0;

            int dDi = 0;
            int dAu = 0;
            int dTu = 0;
            int dFr = 0;

            int pDi = 0;
            int pAu = 0;
            int pTu = 0;
            int pFr = 0;

            if (Dinamarca > Tunisia)
            {
                vDi++;
                dTu++;
            }
            else if (Dinamarca == Tunisia)
            {
                eDi++;
                eTu++;

            }
            else if (Dinamarca < Tunisia)
            {
                vTu++;
                dDi++;

            }
            /*-------------------------------------*/
            if (Australia > França)
            {
                vAu++;
                dFr++;
            }
            else if (Australia == França)
            {
                eAu++;
                eFr++;

            }
            else if (Australia < França)
            {
                vFr++;
                dAu++;
            }
            /*-------------------------------------*/
            if (Australia2 > Tunisia2)
            {
                vAu++;
                dTu++;
            }
            else if (Australia2 == Tunisia2)
            {
                eAu++;
                eTu++;

            }
            else if (Australia2 < Tunisia2)
            {
                vTu++;
                dAu++;

            }

            /*-------------------------------------*/
            if (Dinamarca2 > França2)
            {
                vDi++;
                dFr++;
            }
            else if (Dinamarca2 == França2)
            {
                eDi++;
                eFr++;

            }
            else if (Dinamarca2 < França2)
            {
                vFr++;
                dDi++;

            }
            /*-------------------------------------*/
            if (Tunisia3 > França3)
            {
                vTu++;
                dFr++;
            }
            else if (Tunisia3 == França3)
            {
                eTu++;
                eFr++;

            }
            else if (Tunisia3 < França3)
            {
                vFr++;
                dTu++;

            }
            /*-------------------------------------*/
            if (Australia3 > Dinamarca3)
            {
                vAu++;
                dDi++;
            }
            else if (Australia3 == Dinamarca3)
            {
                eAu++;
                eDi++;

            }
            else if (Australia3 < Dinamarca3)
            {
                vDi++;
                dAu++;

            }
            /*-------------------------------------*/
            /*-------------------------------------*/

            if (Dinamarca > Tunisia)
            {
                pDi += 3;
            }
            else if (Dinamarca == Tunisia)
            {
                pDi++;
                pTu++;

            }
            else if (Dinamarca < Tunisia)
            {
                pTu += 3;

            }
            /*-------------------------------------*/
            if (Australia > França)
            {
                pAu += 3;
            }
            else if (Australia == França)
            {
                pAu++;
                pFr++;

            }
            else if (Australia < França)
            {
                pFr += 3;
            }
            /*-------------------------------------*/
            if (Australia2 > Tunisia2)
            {
                pAu += 3;
            }
            else if (Australia2 == Tunisia2)
            {
                pAu++;
                pTu++;

            }
            else if (Australia2 < Tunisia2)
            {
                pTu += 3;

            }
            /*-------------------------------------*/
            if (Dinamarca2 > França2)
            {
                pDi += 3;
            }
            else if (Dinamarca2 == França2)
            {
                pDi++;
                pFr++;

            }
            else if (Dinamarca2 < França2)
            {
                pFr += 3;

            }
            /*-------------------------------------*/
            if (Tunisia3 > França3)
            {
                pTu += 3;
            }
            else if (Tunisia3 == França3)
            {
                pTu++;
                pFr++;

            }
            else if (Tunisia3 < França3)
            {
                pFr += 3;

            }
            /*-------------------------------------*/
            if (Australia3 > Dinamarca3)
            {
                pAu += 3;
            }
            else if (Australia3 == Dinamarca3)
            {
                pAu++;
                pDi++;

            }
            else if (Australia3 < Dinamarca3)
            {
                pDi += 3;

            }


            Console.WriteLine("\n\nClassificações do Grupo D:");


            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação do México:");
            Console.WriteLine("Vitorias: " + vDi + "");
            Console.WriteLine("Empates:" + eDi + "");
            Console.WriteLine("Derrotas: " + dDi + "");
            Console.WriteLine("Golos Marcados: " + gDi + " ");
            Console.WriteLine("Pontos: " + pDi + " ");
            Console.WriteLine("___________________________");


            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação do Polónia:");
            Console.WriteLine("Vitorias: " + vFr + "");
            Console.WriteLine("Empates:" + eFr + "");
            Console.WriteLine("Derrotas: " + dFr + "");
            Console.WriteLine("Golos Marcados: " + gFr + " ");
            Console.WriteLine("Pontos: " + pFr + " ");
            Console.WriteLine("___________________________");



            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação do Argentina:");
            Console.WriteLine("Vitorias: " + vAu + "");
            Console.WriteLine("Empates:" + eAu + "");
            Console.WriteLine("Derrotas: " + dAu + "");
            Console.WriteLine("Golos Marcados: " + gAu + " ");
            Console.WriteLine("Pontos: " + pAu + " ");
            Console.WriteLine("___________________________");



            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação do Arábia Saudita:");
            Console.WriteLine("Vitorias: " + vTu + "");
            Console.WriteLine("Empates:" + eTu + "");
            Console.WriteLine("Derrotas: " + dTu + "");
            Console.WriteLine("Golos Marcados: " + gTu + " ");
            Console.WriteLine("Pontos: " + pTu + " ");
            Console.WriteLine("___________________________");


            Console.WriteLine("\n\nClica na tecla ENTER para continuar no proximo Grupo!");
            Console.ReadKey();
            Console.Clear();





            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("\n  ------------------");
            Console.WriteLine(" |     GRUPO E      |");
            Console.WriteLine(" |------------------|");
            Console.WriteLine(" |      Alemanha    |");
            Console.WriteLine(" |      Espanha     |");
            Console.WriteLine(" |       Japão      |");
            Console.WriteLine(" |    Costa Rica    |");
            Console.WriteLine(" |------------------|");
            Console.ResetColor();




            Console.WriteLine("\n\n\nGrupo E 1º jogo:");
            string[] array21 = { "Alemanha", "Japão" };

            Random rnd57 = new Random();
            int Alemanha = rnd1.Next(0, 1);
            Random rnd58 = new Random();
            int Japao = rnd2.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Alemanha VS Japão qual vai ser o vencedor:");

            if (Alemanha > Japao)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Alemanha venceu!\n");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
            }
            else if (Alemanha == Japao)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Alemanha < Japao)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Japão venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            Console.WriteLine("Alemanha: " + Alemanha + " golos");
            Console.WriteLine("Japão: " + Japao + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");





            Console.WriteLine("\n\nGrupo E 2 jogo:");
            string[] array22 = { "Espanha", "Costa Rica" };

            Random rnd59 = new Random();
            int Espanha = rnd3.Next(0, 8);
            Random rnd60 = new Random();
            int CostaRica = rnd4.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Espanha VS Costa Rica qual vai ser o vencedor:");

            if (Espanha > CostaRica)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Espanha venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Espanha == CostaRica)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Espanha < CostaRica)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Costa Rica venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Espanha: " + Espanha + " golos");
            Console.WriteLine("Costa Rica: " + CostaRica + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");





            Console.WriteLine("\n\n\nGrupo E 3º jogo:");
            string[] array23 = { "Japão", "Costa Rica" };

            Random rnd61 = new Random();
            int Japao2 = rnd3.Next(0, 4);
            Random rnd62 = new Random();
            int CostaRica2 = rnd4.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("Jogo: Japão VS Costa Rica quem vai ser o vencedor:");

            if (Japao2 > CostaRica2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Espanha venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Japao2 == CostaRica2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Japao2 < CostaRica2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Costa Rica venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Japão: " + Japao2 + " golos");
            Console.WriteLine("Costa Rica: " + CostaRica2 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");









            Console.WriteLine("\n\n\nGrupo E 4º jogo:");
            string[] array24 = { "Espanha", "Alemanha" };

            Random rnd63 = new Random();
            int Espanha2 = rnd3.Next(0, 2);
            Random rnd64 = new Random();
            int Alemanha2 = rnd4.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Espanha VS Alemanha qual vai ser o vencedor:");

            if (Espanha2 > Alemanha2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Espanha venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Espanha2 == Alemanha2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Espanha2 < Alemanha2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Alemanha venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Espanha: " + Espanha2 + " golos");
            Console.WriteLine("Alemanha: " + Alemanha2 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");






            Console.WriteLine("\n\n\nGrupo E 5º jogo:");
            string[] array25 = { "Costa Rica", "Alemanha" };

            Random rnd65 = new Random();
            int CostaRica3 = rnd1.Next(0, 2);
            Random rnd66 = new Random();
            int Alemanha3 = rnd2.Next(0, 4);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Costa Rica VS Alemanha vai ser o vencedor:");

            if (CostaRica3 > Alemanha3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Costa Rica venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (CostaRica3 == Alemanha3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (CostaRica3 < Alemanha3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Alemanha venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Costa Rica: " + CostaRica3 + " golos");
            Console.WriteLine("Alemanha: " + Alemanha3 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");






            Console.WriteLine("\n\n\nGrupo E 6º jogo:");
            string[] array26 = { "Japão", "Espanha" };

            Random rnd67 = new Random();
            int Japao3 = rnd3.Next(0, 1);
            Random rnd68 = new Random();
            int Espanha3 = rnd4.Next(0, 1);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Japão VS Espanha qual vai ser o vencedor:");

            if (Japao3 > Espanha3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Japão venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Japao3 == Espanha3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Japao3 < Espanha3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Espanha venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Japão: " + Japao3 + " golos");
            Console.WriteLine("Espanha: " + Espanha3 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");


            int gjap = Japao + Japao2 + Japao3;
            int ges = Espanha + Espanha2 + Espanha3;
            int gale = Alemanha + Alemanha2 + Alemanha3;
            int gcos = CostaRica + CostaRica2 + CostaRica3;

            int vjap = 0;
            int ves = 0;
            int vale = 0;
            int vcos = 0;

            int ejap = 0;
            int ees = 0;
            int eale = 0;
            int ecos = 0;

            int djap = 0;
            int des = 0;
            int dale = 0;
            int dcos = 0;

            int pjap = 0;
            int pes = 0;
            int pale = 0;
            int pcos = 0;

            if (Alemanha > Japao)
            {
                vale++;
                djap++;
            }
            else if (Alemanha == Japao)
            {
                eale++;
                ejap++;

            }
            else if (Alemanha < Japao)
            {
                vjap++;
                dale++;

            }
            /*-------------------------------------*/
            if (Espanha > CostaRica)
            {
                ves++;
                dcos++;
            }
            else if (Espanha == CostaRica)
            {
                ees++;
                ecos++;

            }
            else if (Espanha < CostaRica)
            {
                vcos++;
                des++;

            }
            /*-------------------------------------*/
            if (Japao2 > CostaRica2)
            {
                vjap++;
                dcos++;
            }
            else if (Japao2 == CostaRica2)
            {
                ejap++;
                ecos++;

            }
            else if (Japao2 < CostaRica2)
            {
                vcos++;
                djap++;

            }
            /*-------------------------------------*/
            if (Alemanha2 > Espanha2)
            {
                vale++;
                des++;
            }
            else if (Alemanha2 == Espanha2)
            {
                eale++;
                ees++;

            }
            else if (Alemanha2 < Espanha2)
            {
                ves++;
                dale++;

            }
            /*-------------------------------------*/
            if (Alemanha3 > CostaRica3)
            {
                vale++;
                dcos++;
            }
            else if (Alemanha3 == CostaRica3)
            {
                eale++;
                ecos++;

            }
            else if (Alemanha3 < CostaRica3)
            {
                vcos++;
                dale++;

            }
            /*-------------------------------------*/
            if (Japao3 > Espanha3)
            {
                vjap++;
                des++;
            }
            else if (Japao3 == Espanha3)
            {
                ejap++;
                ees++;

            }
            else if (Japao3 < Espanha3)
            {
                ves++;
                djap++;

            }
            /*-------------------------------------*/
            /*-------------------------------------*/

            if (Alemanha > Japao)
            {
                pale += 3;
            }
            else if (Alemanha == Japao)
            {
                pale++;
                pjap++;

            }
            else if (Alemanha < Japao)
            {
                pjap += 3;

            }
            /*-------------------------------------*/
            if (Espanha > CostaRica)
            {
                pes += 3;
            }
            else if (Espanha == CostaRica)
            {
                pes++;
                pcos++;

            }
            else if (Espanha < CostaRica)
            {
                pcos += 3;

            }
            /*-------------------------------------*/
            if (Japao2 > CostaRica2)
            {
                pjap += 3;
            }
            else if (Japao2 == CostaRica2)
            {
                pjap++;
                pcos++;

            }
            else if (Japao2 < CostaRica2)
            {
                pcos += 3;

            }
            /*-------------------------------------*/
            if (Alemanha2 > Espanha2)
            {
                pale += 3;
            }
            else if (Alemanha2 == Espanha2)
            {
                pale++;
                pes++;

            }
            else if (Alemanha2 < Espanha2)
            {
                pes += 3;

            }
            /*-------------------------------------*/
            if (Alemanha3 > CostaRica3)
            {
                pale += 3;
            }
            else if (Alemanha3 == CostaRica3)
            {
                pale++;
                pcos++;

            }
            else if (Alemanha3 < CostaRica3)
            {
                pcos += 3;

            }
            /*-------------------------------------*/
            if (Japao3 > Espanha3)
            {
                pjap += 3;
            }
            else if (Japao3 == Espanha3)
            {
                pjap++;
                pes++;

            }
            else if (Japao3 < Espanha3)
            {
                pes += 3;

            }


            Console.WriteLine("\n\nClassificações do Grupo E:");

            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação do Japão:");
            Console.WriteLine("Vitorias: " + vjap + "");
            Console.WriteLine("Empates:" + ejap + "");
            Console.WriteLine("Derrotas: " + djap + "");
            Console.WriteLine("Golos Marcados: " + gjap + " ");
            Console.WriteLine("Pontos: " + pjap + " ");
            Console.WriteLine("___________________________");


            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação da Espanha:");
            Console.WriteLine("Vitorias: " + ves + "");
            Console.WriteLine("Empates:" + ees + "");
            Console.WriteLine("Derrotas: " + des + "");
            Console.WriteLine("Golos Marcados: " + ges + " ");
            Console.WriteLine("Pontos: " + pes + " ");
            Console.WriteLine("___________________________");



            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação da Alemanha:");
            Console.WriteLine("Vitorias: " + vale + "");
            Console.WriteLine("Empates:" + eale + "");
            Console.WriteLine("Derrotas: " + dale + "");
            Console.WriteLine("Golos Marcados: " + gale + " ");
            Console.WriteLine("Pontos: " + pale + " ");
            Console.WriteLine("___________________________");



            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação da Costa Rica:");
            Console.WriteLine("Vitorias: " + vcos + "");
            Console.WriteLine("Empates:" + ecos + "");
            Console.WriteLine("Derrotas: " + dcos + "");
            Console.WriteLine("Golos Marcados: " + gcos + " ");
            Console.WriteLine("Pontos: " + pcos + " ");
            Console.WriteLine("___________________________");



            Console.WriteLine("\n\nClica na tecla ENTER para continuar no proximo Grupo!");
            Console.ReadKey();
            Console.Clear();




            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("\n  ------------------");
            Console.WriteLine(" |     GRUPO F      |");
            Console.WriteLine(" |------------------|");
            Console.WriteLine(" |      Marrocos    |");
            Console.WriteLine(" |      Croácia     |");
            Console.WriteLine(" |      Bélgica     |");
            Console.WriteLine(" |      Canada      |");
            Console.WriteLine(" |------------------|");
            Console.ResetColor();




            Console.WriteLine("\n\n\nGrupo F 1º jogo:");
            string[] array27 = { "Marrocos", "Croácia" };

            Random rnd69 = new Random();
            int Marrocos = rnd1.Next(0, 2);
            Random rnd70 = new Random();
            int Croacia = rnd2.Next(0, 3);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Marrocos VS Croácia qual vai ser o vencedor:");

            if (Marrocos > Croacia)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Marrocos venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Marrocos == Croacia)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Marrocos < Croacia)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Croácia venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Marrocos: " + Marrocos + " golos");
            Console.WriteLine("Croácia: " + Croacia + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");





            Console.WriteLine("\n\nGrupo F 2 jogo:");
            string[] array28 = { "Bélgica", "Canada" };

            Random rnd71 = new Random();
            int Belgica = rnd3.Next(0, 8);
            Random rnd72 = new Random();
            int Canada = rnd4.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Bélgica VS Canada qual vai ser o vencedor:");

            if (Belgica > Canada)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Bélgica venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Belgica == Canada)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Belgica < Canada)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Canada venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Bélgica: " + Belgica + " golos");
            Console.WriteLine("Canada: " + Canada + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");





            Console.WriteLine("\n\n\nGrupo F 3º jogo:");
            string[] array29 = { "Bélgica", "Marrocos" };

            Random rnd73 = new Random();
            int Belgica2 = rnd3.Next(0, 2);
            Random rnd74 = new Random();
            int Marrocos2 = rnd4.Next(0, 4);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("Jogo: Bélgica VS Marrocos quem vai ser o vencedor:");

            if (Belgica2 > Marrocos2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Espanha venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Belgica2 == Marrocos2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Belgica2 < Marrocos2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Marrocos venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
           
            }
            Console.WriteLine("Bélgica: " + Belgica2 + " golos");
            Console.WriteLine("Marrocos: " + Marrocos2 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");









            Console.WriteLine("\n\n\nGrupo F 4º jogo:");
            string[] array30 = { "Croácia", "Canada" };

            Random rnd75 = new Random();
            int Croacia2 = rnd3.Next(0, 2);
            Random rnd76 = new Random();
            int Canada2 = rnd4.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Croácia VS Canada qual vai ser o vencedor:");

            if (Croacia2 > Canada2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Croácia venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Croacia2 == Canada2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Croacia2 < Canada2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Canada venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Croácia: " + Croacia2 + " golos");
            Console.WriteLine("Canada: " + Canada2 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");






            Console.WriteLine("\n\n\nGrupo F 5º jogo:");
            string[] array31 = { "Canada", "Marrocos" };

            Random rnd77 = new Random();
            int Canada3 = rnd1.Next(0, 1);
            Random rnd78 = new Random();
            int Marrocos3 = rnd2.Next(0, 3);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Canada VS Marrocos vai ser o vencedor:");

            if (Canada3 > Marrocos3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Canada venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Canada3 == Marrocos3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Canada3 < Marrocos3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Marrocos venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Canada: " + Canada3 + " golos");
            Console.WriteLine("Marrocos: " + Marrocos3 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");






            Console.WriteLine("\n\n\nGrupo F 6º jogo:");
            string[] array32 = { "Croácia", "Bélgica" };

            Random rnd79 = new Random();
            int Croacia3 = rnd3.Next(0, 1);
            Random rnd80 = new Random();
            int Belgica3 = rnd4.Next(0, 1);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Croácia VS Bélgica qual vai ser o vencedor:");

            if (Croacia3 > Belgica3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Croácia venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Croacia3 == Belgica3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Croacia3 < Belgica3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Bélgica venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Croácia: " + Croacia3 + " golos");
            Console.WriteLine("Bélgica: " + Belgica3 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");

            
            int gmar = Marrocos + Marrocos2 + Marrocos3;
            int gcro = Croacia + Croacia2 + Croacia3;
            int gbel = Belgica + Belgica2 + Belgica3;
            int gcan = Canada + Canada2 + Canada3;

            int vmar = 0;
            int vcro = 0;
            int vbel = 0;
            int vcan = 0;

            int emar = 0;
            int ecro = 0;
            int ebel = 0;
            int ecan = 0;

            int dmar = 0;
            int dcro = 0;
            int dbel = 0;
            int dcan = 0;

            int pmar = 0;
            int pcro = 0;
            int pbel = 0;
            int pcan = 0;

            if (Belgica > Canada)
            {
                vbel++;
                dcan++;
            }
            else if (Belgica == Canada)
            {
                ebel++;
                ecan++;

            }
            else if (Belgica < Canada)
            {
                vcan++;
                dbel++;

            }
            /*-------------------------------------*/
            if (Croacia > Marrocos)
            {
                vcro++;
                dmar++;
            }
            else if (Croacia == Marrocos)
            {
                ecro++;
                emar++;

            }
            else if (Croacia < Marrocos)
            {
                vmar++;
                dcro++;

            }
            /*-------------------------------------*/
            if (Croacia2 > Canada2)
            {
                vcro++;
                dcan++;
            }
            else if (Croacia2 == Canada2)
            {
                ecro++;
                ecan++;

            }
            else if (Croacia2 < Canada2)
            {
                vcan++;
                dcro++;

            }
            /*-------------------------------------*/
            if (Belgica2 > Marrocos2)
            {
                vbel++;
                dmar++;
            }
            else if (Belgica2 == Marrocos2)
            {
                ebel++;
                emar++;

            }
            else if (Belgica2 < Marrocos2)
            {
                vmar++;
                dbel++;

            }
            /*-------------------------------------*/
            if (Canada2 > Marrocos2)
            {
                vcan++;
                dmar++;
            }
            else if (Canada2 == Marrocos2)
            {
                ecan++;
                emar++;
            }
            else if (Canada2 < Marrocos2)
            {
                vmar++;
                dcan++;

            }
            /*-------------------------------------*/
            if (Croacia2 > Belgica2)
            {
                vcro++;
                dcan++;
            }
            else if (Croacia2 == Belgica2)
            {
                ecro++;
                ebel++;

            }
            else if (Croacia2 < Belgica2)
            {
                vbel++;
                dcro++;

            }
            /*-------------------------------------*/
            /*-------------------------------------*/

            if (Belgica > Canada)
            {
                pbel += 3;
            }
            else if (Belgica == Canada)
            {
                pbel++;
                pcan++;

            }
            else if (Belgica < Canada)
            {
                pcan += 3;

            }
            /*-------------------------------------*/
            if (Croacia > Marrocos)
            {
                pcro += 3;
            }
            else if (Croacia == Marrocos)
            {
                pcro++;
                pmar++;

            }
            else if (Croacia < Marrocos)
            {
                pmar += 3;

            }
            /*-------------------------------------*/
            if (Croacia2 > Canada2)
            {
                pcro += 3;
            }
            else if (Croacia2 == Canada2)
            {
                pcro++;
                pcan++;

            }
            else if (Croacia2 < Canada2)
            {
                pcan += 3;

            }
            /*-------------------------------------*/
            if (Belgica2 > Marrocos2)
            {
                pbel += 3;
            }
            else if (Belgica2 == Marrocos2)
            {
                pbel++;
                pmar++;

            }
            else if (Belgica2 < Marrocos2)
            {
                pmar += 3;

            }
            /*-------------------------------------*/
            if (Canada3 > Marrocos3)
            {
                pcan += 3; ;
            }
            else if (Canada3 == Marrocos3)
            {
                pcan++;
                pmar++;
            }
            else if (Canada3 < Marrocos3)
            {
                pmar += 3;

            }
            /*-------------------------------------*/
            if (Croacia3 > Belgica3)
            {
                pcro += 3;
            }
            else if (Croacia3 == Belgica3)
            {
                pcro++;
                pbel++;

            }
            else if (Croacia3 < Belgica3)
            {
                pbel += 3;

            }


            Console.WriteLine("\n\nClassificações do Grupo F:");


            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação do Japão:");
            Console.WriteLine("Vitorias: " + vmar + "");
            Console.WriteLine("Empates:" + emar + "");
            Console.WriteLine("Derrotas: " + dmar + "");
            Console.WriteLine("Golos Marcados: " + gmar + " ");
            Console.WriteLine("Pontos: " + pmar + " ");
            Console.WriteLine("___________________________");


            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação da Espanha:");
            Console.WriteLine("Vitorias: " + vcro + "");
            Console.WriteLine("Empates:" + ecro + "");
            Console.WriteLine("Derrotas: " + dcro + "");
            Console.WriteLine("Golos Marcados: " + gcro + " ");
            Console.WriteLine("Pontos: " + pcro + " ");
            Console.WriteLine("___________________________");



            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação da Alemanha:");
            Console.WriteLine("Vitorias: " + vbel + "");
            Console.WriteLine("Empates:" + ebel + "");
            Console.WriteLine("Derrotas: " + dbel + "");
            Console.WriteLine("Golos Marcados: " + gbel + " ");
            Console.WriteLine("Pontos: " + pbel + " ");
            Console.WriteLine("___________________________");



            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação da Costa Rica:");
            Console.WriteLine("Vitorias: " + vcan + "");
            Console.WriteLine("Empates:" + ecan + "");
            Console.WriteLine("Derrotas: " + dcan + "");
            Console.WriteLine("Golos Marcados: " + gcan + " ");
            Console.WriteLine("Pontos: " + pcan + " ");
            Console.WriteLine("___________________________");


            Console.WriteLine("\n\nClica na tecla ENTER para continuar no proximo Grupo!");
            Console.ReadKey();
            Console.Clear();




            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("\n  ------------------");
            Console.WriteLine(" |     GRUPO G      |");
            Console.WriteLine(" |------------------|");
            Console.WriteLine(" |      Brasil      |");
            Console.WriteLine(" |      Sérvia      |");
            Console.WriteLine(" |       Suiça      |");
            Console.WriteLine(" |     Camarões     |");
            Console.WriteLine(" |------------------|");
            Console.ResetColor();




            Console.WriteLine("\n\n\nGrupo G 1º jogo:");
            string[] array33 = { "Brasil", "Camarões" };

            Random rnd81 = new Random();
            int Brasil = rnd1.Next(0, 1);
            Random rnd82 = new Random();
            int Camaroes = rnd2.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Brasil VS Camarões qual vai ser o vencedor:");

            if (Brasil > Camaroes)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Brasil venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Brasil == Camaroes)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Brasil < Camaroes)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Camarões venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Brasil: " + Brasil + " golos");
            Console.WriteLine("Camarões: " + Camaroes + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");





            Console.WriteLine("\n\nGrupo G 2 jogo:");
            string[] array34 = { "Suiça", "Sérvia" };

            Random rnd83 = new Random();
            int Suiça = rnd3.Next(0, 8);
            Random rnd84 = new Random();
            int Servia = rnd4.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Suiça VS Sérvia qual vai ser o vencedor:");

            if (Suiça > Servia)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Suiça venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Suiça == Servia)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Suiça < Servia)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Sérvia venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Suiça: " + Suiça + " golos");
            Console.WriteLine("Sérvia: " + Servia + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");





            Console.WriteLine("\n\n\nGrupo G 3º jogo:");
            string[] array35 = { "Brasil", "Suiça" };

            Random rnd85 = new Random();
            int Brasil2 = rnd3.Next(0, 2);
            Random rnd86 = new Random();
            int Suiça2 = rnd4.Next(0, 1);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("Jogo: Brasil VS Suiça quem vai ser o vencedor:");

            if (Brasil2 > Suiça2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Brasil venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Brasil2 == Suiça2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Brasil2 < Suiça2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Suiça venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Brasil: " + Brasil2 + " golos");
            Console.WriteLine("Suiça: " + Suiça2 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");









            Console.WriteLine("\n\n\nGrupo G 4º jogo:");
            string[] array36 = { "Camarões", "Sérvia" };

            Random rnd87 = new Random();
            int Camaroes2 = rnd3.Next(0, 2);
            Random rnd88 = new Random();
            int Servia2 = rnd4.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Camarões VS Sérvia qual vai ser o vencedor:");

            if (Camaroes2 > Servia2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Camarões venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Camaroes2 == Servia2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Camaroes2 < Servia2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Sérvia venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Camarões: " + Camaroes2 + " golos");
            Console.WriteLine("Sérvia: " + Servia2 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");






            Console.WriteLine("\n\n\nGrupo G 5º jogo:");
            string[] array37 = { "Brasil", "Sérvia" };

            Random rnd89 = new Random();
            int Brasil3 = rnd1.Next(0, 4);
            Random rnd90 = new Random();
            int Servia3 = rnd2.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Brasil VS Sérvia vai ser o vencedor:");

            if (Brasil3 > Servia3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Brasil venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Brasil3 == Servia3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Brasil3 < Servia3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Sérvia venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Brasil: " + Brasil3 + " golos");
            Console.WriteLine("Sérvia: " + Servia3 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");






            Console.WriteLine("\n\n\nGrupo G 6º jogo:");
            string[] array38 = { "Suiça", "Camarões" };

            Random rnd91 = new Random();
            int Suiça3 = rnd3.Next(0, 1);
            Random rnd92 = new Random();
            int Camaroes3 = rnd4.Next(0, 1);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Suiça VS Camarões qual vai ser o vencedor:");

            if (Suiça3 > Camaroes3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Suiça venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Suiça3 == Camaroes3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Suiça3 < Camaroes3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Camarões venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Suiça: " + Suiça3 + " golos");
            Console.WriteLine("Camarões: " + Camaroes3 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");



            int gbr = Brasil + Brasil2 + Brasil3;
            int gsui = Suiça + Suiça2 + Suiça3;
            int gcam = Camaroes + Camaroes2 + Camaroes3;
            int gser = Servia + Servia2 + Servia3;

            int vbr = 0;
            int vsui = 0;
            int vcam = 0;
            int vser = 0;

            int ebr = 0;
            int esui = 0;
            int ecam = 0;
            int eser = 0;

            int dbr = 0;
            int dsui = 0;
            int dcam = 0;
            int dser = 0;

            int pbr = 0;
            int psui = 0;
            int pcam = 0;
            int pser = 0;


            if (Brasil > Servia)
            {
                vbr++;
                dser++;

            }
            else if (Brasil == Servia)
            {
                ebr++;
                eser++;

            }
            else if (Brasil < Servia)
            {
                vser++;
                dbr++;

            }
            /*-------------------------------------*/
            if (Suiça > Camaroes)
            {
                vsui++;
                dcam++;
            }
            else if (Suiça == Camaroes)
            {
                esui++;
                ecam++;

            }
            else if (Suiça < Camaroes)
            {
                vcam++;
                dsui++;

            }
            /*-------------------------------------*/
            if (Brasil2 > Suiça2)
            {
                vbr++;
                dsui++;
            }
            else if (Brasil2 == Suiça2)
            {
                ebr++;
                esui++;

            }
            else if (Brasil2 < Suiça2)
            {
                vsui++;
                dbr++;

            }
            /*-------------------------------------*/
            if (Camaroes2 > Servia2)
            {
                vcam++;
                dser++;
            }
            else if (Camaroes2 == Servia2)
            {
                ecam++;
                eser++;

            }
            else if (Camaroes2 < Servia2)
            {
                vser++;
                dcam++;

            }
            /*-------------------------------------*/
            if (Camaroes3 > Brasil3)
            {
                vcam++;
                dbr++;
            }
            else if (Camaroes3 == Brasil3)
            {
                ecam++;
                ebr++;

            }
            else if (Camaroes3 < Brasil3)
            {
                vbr++;
                dcam++;

            }
            /*-------------------------------------*/
            if (Suiça3 > Servia3)
            {
                vsui++;
                dser++;
            }
            else if (Suiça3 == Servia3)
            {
                esui++;
                eser++;

            }
            else if (Suiça3 < Servia3)
            {

                vser++;
                dsui++;
            }
            /*-------------------------------------*/
            /*-------------------------------------*/

            if (Brasil > Servia)
            {
                pbr += 3;
            }
            else if (Brasil == Servia)
            {
                pbr++;
                pser++;

            }
            else if (Brasil < Servia)
            {
                pser += 3;

            }
            /*-------------------------------------*/
            if (Suiça > Camaroes)
            {
                psui += 3;
            }
            else if (Suiça == Camaroes)
            {
                psui++;
                pcam++;

            }
            else if (Suiça < Camaroes)
            {
                pcam += 3;

            }
            /*-------------------------------------*/
            if (Brasil2 > Suiça2)
            {
                pbr += 3;
            }
            else if (Brasil2 == Suiça2)
            {
                pbr++;
                psui++;

            }
            else if (Brasil2 < Suiça2)
            {
                psui += 3;

            }
            /*-------------------------------------*/
            if (Camaroes2 > Servia2)
            {
                pcam += 3;
            }
            else if (Camaroes2 == Servia2)
            {
                pcam++;
                pser++;

            }
            else if (Camaroes2 < Servia2)
            {
                pser += 3;

            }
            /*-------------------------------------*/
            if (Camaroes3 > Brasil3)
            {
                pcam += 3;
            }
            else if (Camaroes3 == Brasil3)
            {
                pcam++;
                pbr++;

            }
            else if (Camaroes3 < Brasil3)
            {
                pbr += 3;

            }
            /*-------------------------------------*/
            if (Suiça3 > Servia3)
            {
                psui += 3;
            }
            else if (Suiça3 == Servia3)
            {
                psui++;
                pser++;

            }
            else if (Suiça3 < Servia3)
            {

                pser += 3;

            }


            Console.WriteLine("\n\nClassificações do Grupo G:");


            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação do Japão:");
            Console.WriteLine("Vitorias: " + vbr + "");
            Console.WriteLine("Empates:" + ebr + "");
            Console.WriteLine("Derrotas: " + dbr + "");
            Console.WriteLine("Golos Marcados: " + gbr + " ");
            Console.WriteLine("Pontos: " + pbr + " ");
            Console.WriteLine("___________________________");


            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação da Espanha:");
            Console.WriteLine("Vitorias: " + vsui + "");
            Console.WriteLine("Empates:" + esui + "");
            Console.WriteLine("Derrotas: " + dsui + "");
            Console.WriteLine("Golos Marcados: " + gsui + " ");
            Console.WriteLine("Pontos: " + psui + " ");
            Console.WriteLine("___________________________");



            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação da Alemanha:");
            Console.WriteLine("Vitorias: " + vcam + "");
            Console.WriteLine("Empates:" + ecam + "");
            Console.WriteLine("Derrotas: " + dcam + "");
            Console.WriteLine("Golos Marcados: " + gcam + " ");
            Console.WriteLine("Pontos: " + pcam + " ");
            Console.WriteLine("___________________________");



            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação da Costa Rica:");
            Console.WriteLine("Vitorias: " + vser + "");
            Console.WriteLine("Empates:" + eser + "");
            Console.WriteLine("Derrotas: " + dser + "");
            Console.WriteLine("Golos Marcados: " + gser + " ");
            Console.WriteLine("Pontos: " + pser + " ");
            Console.WriteLine("___________________________");



            Console.WriteLine("\n\nClica na tecla ENTER para continuar no proximo Grupo!");
            Console.ReadKey();
            Console.Clear();



            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("\n  ------------------");
            Console.WriteLine(" |     GRUPO H      |");
            Console.WriteLine(" |------------------|");
            Console.WriteLine(" |      Potugal     |");
            Console.WriteLine(" |       Gana       |");
            Console.WriteLine(" |      Uruguai     |");
            Console.WriteLine(" |  Coreia do sul   |");
            Console.WriteLine(" |------------------|");
            Console.ResetColor();




            Console.WriteLine("\n\n\nGrupo E 1º jogo:");
            string[] array39 = { "Portugal", "Gana" };

            Random rnd93 = new Random();
            int Portugal = rnd1.Next(0, 4);
            Random rnd94 = new Random();
            int Gana = rnd2.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Portugal VS Gana qual vai ser o vencedor:");

            if (Portugal > Gana)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Portugal venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Portugal == Gana)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Portugal < Gana)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Gana venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Portugal: " + Portugal + " golos");
            Console.WriteLine("Gana: " + Gana + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");





            Console.WriteLine("\n\nGrupo H 2 jogo:");
            string[] array40 = { "Uruguai", "Coreia do Sul" };

            Random rnd95 = new Random();
            int Uruguai = rnd3.Next(0, 8);
            Random rnd96 = new Random();
            int CoreiaSul = rnd4.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Uruguai VS Coreia do Sul qual vai ser o vencedor:");

            if (Uruguai > CoreiaSul)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Uruguai venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Uruguai == CoreiaSul)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Uruguai < CoreiaSul)
            {
                Console.Write("Resultado: ");
                Console.Write("Coreia do Sul venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Urugai: " + Uruguai + " golos");
            Console.WriteLine("Coreia do Sul: " + CoreiaSul + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");





            Console.WriteLine("\n\n\nGrupo H 3º jogo:");
            string[] array41 = { "Portugal", "Uruguai" };

            Random rnd97 = new Random();
            int Portugal2 = rnd3.Next(0, 4);
            Random rnd98 = new Random();
            int Uruguai2 = rnd4.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("Jogo Portugal VS Uruguai quem vai ser o vencedor:");

            if (Portugal2 > Uruguai2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Espanha venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Portugal2 == Uruguai2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Portugal2 < Uruguai2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Uruguai venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Portugal: " + Portugal2 + " golos");
            Console.WriteLine("Uruguai: " + Uruguai2 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");









            Console.WriteLine("\n\n\nGrupo H 4º jogo:");
            string[] array42 = { "Coreia do Sul", "Gana" };

            Random rnd99 = new Random();
            int CoreiaSul2 = rnd3.Next(0, 2);
            Random rnd100 = new Random();
            int Gana2 = rnd4.Next(0, 4);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Coreia do Sul VS Gana qual vai ser o vencedor:");

            if (CoreiaSul2 > Gana2)
            {
                Console.Write("Resultado: ");
                Console.Write("Coreia do Sul venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (CoreiaSul2 == Gana2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (CoreiaSul2 < Gana2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Gana venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Coreia do Sul: " + CoreiaSul2 + " golos");
            Console.WriteLine("Gana: " + Gana2 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");






            Console.WriteLine("\n\n\nGrupo H 5º jogo:");
            string[] array43 = { "Urugai", "Gana" };

            Random rnd101 = new Random();
            int Uruguai3 = rnd1.Next(0, 4);
            Random rnd102 = new Random();
            int Gana3 = rnd2.Next(0, 2);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Uruguai VS Gana vai ser o vencedor:");

            if (Uruguai3 > Gana3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Uruguai venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Uruguai3 == Gana3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Uruguai3 < Gana3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Gana venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            Console.WriteLine("Uruguai: " + Uruguai3 + " golos");
            Console.WriteLine("Gana: " + Gana3 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");






            Console.WriteLine("\n\n\nGrupo H 6º jogo:");
            string[] array44 = { "Portugal", "Coreia o Sul" };

            Random rnd103 = new Random();
            int Portugal3 = rnd3.Next(0, 2);
            Random rnd104 = new Random();
            int CoreiaSul3 = rnd4.Next(0, 3);

            Console.WriteLine("\n<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
            Console.WriteLine("JOGO: Portugal VS Coreia do Sul qual vai ser o vencedor:");

            if (Portugal3 > CoreiaSul3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Portugal venceu!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else if (Portugal3 == CoreiaSul3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write("Empate!\n");
                Console.ForegroundColor = ConsoleColor.White;

            }
            else if (Portugal3 < CoreiaSul3)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Coreia do Sul venceu!\n");
                Console.ForegroundColor = ConsoleColor.Green;

            }
            Console.WriteLine("Portugal: " + Portugal3 + " golos");
            Console.WriteLine("Coreia do Sul: " + CoreiaSul3 + " golos");
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>");



            Console.ForegroundColor = ConsoleColor.White;
            int gCs = CoreiaSul + CoreiaSul2 + CoreiaSul3;
            int gPt = Portugal + Portugal2 + Portugal3;
            int gUr = Uruguai + Uruguai2 + Uruguai3;
            int gAn = Gana + Gana2 + Gana3;

            int vCs = 0;
            int vPt = 0;
            int vUr = 0;
            int vAn = 0;

            int eCs = 0;
            int ePt = 0;
            int eUr = 0;
            int eAn = 0;

            int dCs = 0;
            int dPt = 0;
            int dUr = 0;
            int dAn = 0;

            int pCs = 0;
            int pPt = 0;
            int pUr = 0;
            int pAn = 0;


            if (Portugal > Gana)
            {
                vPt++;
                dAn++;

            }
            else if (Portugal == Gana)
            {
                ePt++;
                eAn++;

            }
            else if (Portugal < Gana)
            {

                vAn++;
                dPt++;
            }
            /*-------------------------------------*/
            if (Uruguai > CoreiaSul)
            {
                vUr++;
                dCs++;
            }
            else if (Uruguai == CoreiaSul)
            {
                eUr++;
                eCs++;

            }
            else if (Uruguai < CoreiaSul)
            {
                vCs++;
                dUr++;

            }
            /*-------------------------------------*/
            if (Portugal2 > Uruguai2)
            {
                vPt++;
                dUr++;
            }
            else if (Portugal2 == Uruguai2)
            {
                ePt++;
                eUr++;
            }
            else if (Portugal2 < Uruguai2)
            {
                vUr++;
                dPt++;

            }
            /*-------------------------------------*/
            if (CoreiaSul2 > Gana2)
            {
                vCs++;
                dAn++;
            }
            else if (CoreiaSul2 == Gana2)
            {
                eCs++;
                eAn++;

            }
            else if (CoreiaSul2 < Gana2)
            {
                vAn++;
                dCs++;

            }
            /*-------------------------------------*/
            if (Uruguai3 > Gana3)
            {
                vUr++;
                dAn++;

            }
            else if (Uruguai3 == Gana3)
            {
                eUr++;
                eAn++;

            }
            else if (Uruguai3 < Gana3)
            {
                vAn++;
                dUr++;

            }
            /*-------------------------------------*/
            if (Portugal3 > CoreiaSul3)
            {
                vPt++;
                dCs++;

            }
            else if (Portugal3 == CoreiaSul3)
            {
                ePt++;
                eCs++;

            }
            else if (Portugal3 < CoreiaSul3)
            {

                vCs++;
                dPt++;
            }
            /*-------------------------------------*/
            /*-------------------------------------*/

            if (Portugal > Gana)
            {
                pPt += 3;

            }
            else if (Portugal == Gana)
            {
                pPt++;
                pAn++;
            }
            else if (Portugal < Gana)
            {
                pAn += 3;
            }
            /*-------------------------------------*/
            if (Uruguai > CoreiaSul)
            {
                pUr += 3;
            }
            else if (Uruguai == CoreiaSul)
            {
                pUr++;
                pCs++;

            }
            else if (Uruguai < CoreiaSul)
            {
                pCs += 3;

            }
            /*-------------------------------------*/
            if (Portugal2 > Uruguai2)
            {
                pPt += 3;
            }
            else if (Portugal2 == Uruguai2)
            {
                pPt++;
                pUr++;
            }
            else if (Portugal2 < Uruguai2)
            {
                pUr += 3;

            }
            /*-------------------------------------*/
            if (CoreiaSul2 > Gana2)
            {
                pCs += 3;
            }
            else if (CoreiaSul2 == Gana2)
            {
                pCs++;
                pAn++;

            }
            else if (CoreiaSul2 < Gana2)
            {
                pAn += 3;

            }
            /*-------------------------------------*/
            if (Uruguai3 > Gana3)
            {
                pUr += 3;

            }
            else if (Uruguai3 == Gana3)
            {
                pUr++;
                pAn++;

            }
            else if (Uruguai3 < Gana3)
            {
                pAn += 3;

            }
            /*-------------------------------------*/
            if (Portugal3 > CoreiaSul3)
            {
                pPt += 3;

            }
            else if (Portugal3 == CoreiaSul3)
            {
                pPt++;
                pCs++;

            }
            else if (Portugal3 < CoreiaSul3)
            {

                pCs += 3;

            }


            Console.WriteLine("\n\nClassificações do Grupo H:");


            Console.WriteLine("___________________________");

            Console.WriteLine("Classificação do Coreia do Sul:");
            Console.WriteLine("Vitorias: " + vCs + "");
            Console.WriteLine("Empates:" + eCs + "");
            Console.WriteLine("Derrotas: " + dCs + "");
            Console.WriteLine("Golos Marcados: " + gCs + " ");
            Console.WriteLine("Pontos: " + pCs + " ");
            Console.WriteLine("___________________________");


            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação da Portugal:");
            Console.WriteLine("Vitorias: " + vPt + "");
            Console.WriteLine("Empates:" + ePt + "");
            Console.WriteLine("Derrotas: " + dPt + "");
            Console.WriteLine("Golos Marcados: " + gPt + " ");
            Console.WriteLine("Pontos: " + pPt + " ");
            Console.WriteLine("___________________________");



            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação da Uruguai:");
            Console.WriteLine("Vitorias: " + vUr + "");
            Console.WriteLine("Empates:" + eUr + "");
            Console.WriteLine("Derrotas: " + dUr + "");
            Console.WriteLine("Golos Marcados: " + gUr + " ");
            Console.WriteLine("Pontos: " + pUr + " ");
            Console.WriteLine("___________________________");



            Console.WriteLine("\n\n\n\n___________________________");

            Console.WriteLine("Classificação da Gana:");
            Console.WriteLine("Vitorias: " + vAn + "");
            Console.WriteLine("Empates:" + eAn + "");
            Console.WriteLine("Derrotas: " + dAn + "");
            Console.WriteLine("Golos Marcados: " + gAn + " ");
            Console.WriteLine("Pontos: " + pAn + " ");
            Console.WriteLine("___________________________");



            int grupoA1 = 0;
            int grupoA2 = 0;




            //Qatar- Senegal- Nethelands- Equador

            if (pQa > pSe && pQa > pEq && pQa > pNt)
            {

                grupoA1 = pQa;
                GrupoA[0] = "Qatar";

                if (pSe > pEq && pSe > pNt)
                {
                    GrupoA[0] = "Qatar";
                    GrupoA[1] = "Senegal";
                    grupoA2 = pSe;
                }
                else if (pEq > pSe && pEq > pNt)
                {
                    GrupoA[0] = "Qatar";
                    GrupoA[1] = "Equador";
                    grupoA2 = pEq;
                }
                else
                {
                    GrupoA[0] = "Qatar";
                    GrupoA[1] = "Netherlands";
                    grupoA2 = pNt;
                }

            }
            else if (pSe > pQa && pSe > pEq && pSe > pNt)
            {

                grupoA1 = pSe;
                GrupoA[0] = "Senegal";
                if (pQa > pEq && pQa > pNt)
                {
                    GrupoA[0] = "Senegal";
                    GrupoA[1] = "Qatar";
                    grupoA2 = pQa;
                }
                else if (pEq > pQa && pEq > pNt)
                {
                    GrupoA[0] = "Senegal";
                    GrupoA[1] = "Equador";
                    grupoA2 = pEq;
                }
                else
                {
                    GrupoA[0] = "Senegal";
                    GrupoA[1] = "Netherlands";
                    grupoA2 = pNt;
                }
            }
            else if (pEq > pQa && pEq > pSe && pEq > pNt)
            {
                grupoA1 = pEq;
                GrupoA[0] = "Equador";
                if (pQa > pSe && pQa > pNt)
                {
                    GrupoA[0] = "Equador";
                    GrupoA[1] = "Qatar";
                    grupoA2 = pQa;
                }
                else if (pSe > pQa && pSe > pNt)
                {
                    GrupoA[0] = "Equador";
                    GrupoA[1] = "Senegal";
                    grupoA2 = pSe;
                }
                else
                {
                    GrupoA[0] = "Equador";
                    GrupoA[1] = "Netherlands";
                    grupoA2 = pNt;
                }
            }
            else
            {
                grupoA1 = pNt;
                GrupoA[0] = "Netherlands";
                if (pQa > pSe && pQa > pEq)
                {
                    GrupoA[0] = "Netherlands";
                    GrupoA[1] = "Qatar";
                    grupoA2 = pQa;
                }
                else if (pSe > pQa && pSe > pEq)
                {
                    GrupoA[0] = "Netherlands";
                    GrupoA[1] = "Senegal";
                    grupoA2 = pSe;
                }
                else
                {
                    GrupoA[0] = "Netherlands";
                    GrupoA[1] = "Equador";
                    grupoA2 = pEq;
                }
            }


           
            
            //Inglaterra- Estados Unidos- Irão- País de Gales
           

            int gbl1 = 0;
            int gbl2 = 0;

            if (pIg > pEu && pIg > pIr && pIg > pPg)
            {
                gbl1 = pIg;
                GrupoB[0] = "Inglaterra";
                if (pEu > pIr && pEu > pPg)
                {
                    GrupoB[0] = "Inglaterra";
                    GrupoB[1] = "Estados Unidos";
                    gbl2 = pEu;
                }
                else if (pIr > pEu && pIr > pPg)
                {
                    GrupoB[0] = "Inglaterra";
                    GrupoB[1] = "Irã";
                    gbl2 = pIr;
                }
                else
                {
                    GrupoB[0] = "Inglaterra";
                    GrupoB[1] = "País de Gales";
                    gbl2 = pPg;
                }
            }
            else if (pEu > pIg && pEu > pIr && pEu > pPg)
            {
                gbl1 = pEu;
                GrupoB[0] = "Estados Unidos";

                if (pIg > pIr && pIg > pPg)
                {
                    GrupoB[0] = "Estados Unidos";
                    GrupoB[1] = "Inglaterra";
                    gbl2 = pIg;
                }
                else if (pIr > pIg && pIr > pPg)
                {
                    GrupoB[0] = "Estados Unidos";
                    GrupoB[1] = "Irã";
                    gbl2 = pIr;
                }
                else
                {
                    GrupoB[0] = "Estados Unidos";
                    GrupoB[1] = "País de Gales";
                    gbl2 = pPg;
                }
            }
            else if (pIr > pIg && pIr > pEu && pIr > pPg)
            {
                gbl1 = pIr;
                GrupoB[0] = "Irão";
                if (pIg > pEu && pIg > pPg)
                {
                    GrupoB[0] = "Irão";
                    GrupoB[1] = "Inglaterra";
                    gbl2 = pIg;
                }
                else if (pEu > pIg && pEu > pPg)
                {
                    GrupoB[0] = "Irão";
                    GrupoB[1] = "Estados Unidos";
                    gbl2 = pEu;
                }
                else
                {
                    GrupoB[0] = "Irão";
                    GrupoB[1] = "País de Gales";
                    gbl2 = pPg;
                }
            }
            else
            {
                gbl1 = pPg;
                GrupoB[0] = "País de Gales";
                if (pIg > pEu && pIg > pIr)
                {
                    GrupoB[0] = "País de Gales";
                    GrupoB[1] = "Inglerra";
                    gbl2 = pIg;
                }
                else if (pEu > pIg && pEu > pIr)
                {
                    GrupoB[0] = "País de Gales";
                    GrupoB[1] = "Estados Unidos";
                    gbl2 = pEu;
                }
                else
                {
                    GrupoB[0] = "País de Gales";
                    GrupoB[1] = "Irão";
                    gbl2 = pIr;
                }
            }



           
            
            //Arabia Saudita- Polonia- Argentina- México
                      
            
             
            int gcl1 = 0;
            int gcl2 = 0;

            if (pAg > pPo && pAg > pMe && pAg > pAr)
            {
                gcl1 = pAg;
                GrupoC[0] = "Argentina";

                if (pPo > pMe && pPo > pAr)
                {
                    GrupoC[0] = "Argentina";
                    GrupoC[1] = "Polonia";
                    gcl2 = pPo;
                }
                else if (pMe > pPo && pMe > pAr)
                {
                    GrupoC[0] = "Argentina";
                    GrupoC[1] = "Mexico";
                    gcl2 = pMe;
                }
                else
                {
                    GrupoC[0] = "Argentina";
                    GrupoC[1] = "Arabia Saudita";
                    gcl2 = pAr;
                }
            }
            else if (pPo > pAg && pPo > pMe && pPo > pAr)
            {
                gcl1 = pPo;
                GrupoC[0] = "Polonia";

                if (pAg > pMe && pAg > pAr)
                {
                    GrupoC[0] = "Polonia";
                    GrupoC[1] = "Argentina";
                    gcl2 = pAg;
                }
                else if (pMe > pAg && pMe > pAr)
                {
                    GrupoC[0] = "Polonia";
                    GrupoC[1] = "Mexico";
                    gcl2 = pMe;
                }
                else
                {
                    GrupoC[0] = "Polonia";
                    GrupoC[1] = "Argentina";
                    gcl2 = pAr;
                }
            }
            else if (pMe > pAg && pMe > pPo && pMe > pAr)
            {
                gcl1 = pMe;
                GrupoC[0] = "Mexico";

                if (pAg > pPo && pAg > pAr)
                {
                    GrupoC[0] = "Mexico";
                    GrupoC[1] = "Argentina";
                    gcl2 = pAg;
                }
                else if (pPo > pAg && pPo > pAr)
                {
                    GrupoC[0] = "Mexico";
                    GrupoC[1] = "Polonia";
                    gcl2 = pPo;
                }
                else
                {
                    GrupoC[0] = "Mexico";
                    GrupoC[1] = "Arabia Saudita";
                    gcl2 = pAr;
                }
            }
            else
            {
                gcl1 = pAr;
                GrupoC[0] = "Arabia Saudita";

                if (pAg > pPo && pAg > pMe)
                {
                    GrupoC[0] = "Arabia";
                    GrupoC[1] = "Argentina";
                    gcl2 = pAg;
                }
                else if (pPo > pAg && pPo > pMe)
                {
                    GrupoC[0] = "Arabia Saudita";
                    GrupoC[1] = "Polonia";
                    gcl2 = pPo;
                }
                else
                {
                    GrupoC[0] = "Arabia Saudita";
                    GrupoC[1] = "Mexico";
                    gcl2 = pMe;
                }
            }
            


           
            
            //França- Austrália- Tunisia- Dinamarca
                        
             

            int gdl1 = 0;
            int gdl2 = 0;

            if (pFr > pAu && pFr > pTu && pFr > pDi)
            {
                gdl1 = pFr;
                GrupoD[0] = "França";

                if (pAu > pTu && pAu > pDi)
                {
                    GrupoD[0] = "França";
                    GrupoD[1] = "Australia";
                    gdl2 = pAu;
                }
                else if (pTu > pAu && pTu > pDi)
                {
                    GrupoD[0] = "França";
                    GrupoD[1] = "Tunisia";
                    gdl2 = pTu;
                }
                else
                {
                    GrupoD[0] = "França";
                    GrupoD[1] = "Dinamarca";
                    gdl2 = pDi;
                }
            }
            else if (pAu > pFr && pAu > pTu && pAu > pDi)
            {
                gdl1 = pAu;
                GrupoD[0] = "Australia";
                if (pFr > pTu && pFr > pDi)
                {
                    GrupoD[0] = "Australia";
                    GrupoD[1] = "França";
                    gdl2 = pFr;
                }
                else if (pTu > pFr && pTu > pDi)
                {
                    GrupoD[0] = "Australia";
                    GrupoD[1] = "Tunisia";
                    gdl2 = pTu;
                }
                else
                {
                    GrupoD[0] = "Australia";
                    GrupoD[1] = "Dinamarca";
                    gdl2 = pDi;
                }
            }
            else if (pTu > pFr && pTu > pAu && pTu > pDi)
            {
                gdl1 = pTu;
                GrupoD[0] = "Tunisia";
                if (pFr > pAu && pFr > pDi)
                {
                    GrupoD[0] = "Tunisia";
                    GrupoD[1] = "França";
                    gdl2 = pFr;
                }
                else if (pAu > pFr && pAu > pDi)
                {
                    GrupoD[0] = "Tunisia";
                    GrupoD[1] = "Australia";
                    gdl2 = pAu;
                }
                else
                {
                    GrupoD[0] = "Tunisia";
                    GrupoD[1] = "Dinamarca";
                    gdl2 = pDi;
                }
            }
            else
            {
                gdl1 = pDi;
                GrupoD[0] = "Dinamarca";

                if (pFr > pAu && pFr > pTu)
                {
                    GrupoD[0] = "Dinamarca";
                    GrupoD[1] = "França";
                    gdl2 = pFr;
                }
                else if (pAu > pFr && pAu > pTu)
                {
                    GrupoD[0] = "Dinamarca";
                    GrupoD[1] = "Australia";
                    gdl2 = pAu;
                }
                else
                {
                    GrupoD[0] = "Dinamarca";
                    GrupoD[1] = "Tunisia";
                    gdl2 = pTu;
                }
            }
            

           
            
            //Japão- Espanha- Alemanha- Costa Rica
                    
            
            int gel1 = 0;
            int gel2 = 0;

            if (pjap > pes && pjap > pale && pjap > pcos)
            {
                gel1 = pjap;
                GrupoE[0] = "Japão";

                if (pes > pale && pes > pcos)
                {
                    GrupoE[0] = "Japão";
                    GrupoE[1] = "Espanha";
                    gel2 = pes;
                }
                else if (pale > pes && pale > pcos)
                {
                    GrupoE[0] = "Japão";
                    GrupoE[1] = "Alemanha";
                    gel2 = pale;
                }
                else
                {
                    GrupoE[0] = "Japão";
                    GrupoE[1] = "Costa Rica";
                    gel2 = pcos;
                }
            }
            else if (pes > pjap && pes > pale && pes > pcos)
            {
                gel1 = pes;
                GrupoE[0] = "Espanha";

                if (pjap > pale && pjap > pcos)
                {
                    GrupoE[0] = "Espanha";
                    GrupoE[1] = "Japão";
                    gel2 = pjap;
                }
                else if (pale > pjap && pale > pcos)
                {
                    GrupoE[0] = "Espanha";
                    GrupoE[1] = "Alemanha";
                    gel2 = pale;
                }
                else
                {
                    GrupoE[0] = "Espanha";
                    GrupoE[1] = "Costa Rica";
                    gel2 = pcos;
                }
            }
            else if (pale > pjap && pale > pes && pale > pcos)
            {
                gel1 = pale;
                GrupoE[0] = "Alemanha";

                if (pjap > pes && pjap > pcos)
                {
                    GrupoE[0] = "Alemanha";
                    GrupoE[1] = "Japão";
                    gel2 = pjap;
                }
                else if (pes > pjap && pes > pcos)
                {
                    GrupoE[0] = "Alemanha";
                    GrupoE[1] = "Espanha";
                    gel2 = pes;
                }
                else
                {
                    GrupoE[0] = "Alemanha";
                    GrupoE[1] = "Costa Rica";
                    gel2 = pcos;
                }
            }
            else
            {
                gel1 = pcos;
                GrupoA[0] = "Costa Rica";

                if (pjap > pes && pjap > pale)
                {
                    GrupoE[0] = "Costa Rica";
                    GrupoE[1] = "Japão";
                    gel2 = pjap;
                }
                else if (pes > pjap && pes > pale)
                {
                    GrupoE[0] = "Costa Rica";
                    GrupoE[1] = "Espanha";
                    gel2 = pes;
                }
                else
                {
                    GrupoE[0] = "Costa Rica";
                    GrupoE[1] = "Alemanha";
                    gel2 = pale;
                }
            }
            

            
            
            //Marrocos- Croácia- Canada- Bélgica
                       
            
            int gfl1 = 0;
            int gfl2 = 0;

            if (pmar > pcro && pmar > pbel && pmar > pcan)
            {
                gfl1 = pmar;
                GrupoF[0] = "Marrocos";

                if (pcro > pbel && pcro > pcan)
                {
                    GrupoF[0] = "Marrocos";
                    GrupoF[1] = "Croacia";
                    gfl2 = pcro;
                }
                else if (pbel > pcro && pbel > pcan)
                {
                    GrupoF[0] = "Marrocos";
                    GrupoF[1] = "Belgica";
                    gfl2 = pbel;
                }
                else
                {
                    GrupoF[0] = "Marrocos";
                    GrupoF[1] = "Canada";
                    gfl2 = pcan;
                }
            }
            else if (pcro > pmar && pcro > pbel && pcro > pcan)
            {
                gfl1 = pcro;
                GrupoF[0] = "Croacia";

                if (pmar > pbel && pmar > pcan)
                {
                    GrupoF[0] = "Croacia";
                    GrupoF[1] = "Marrocos";
                    gfl2 = pmar;
                }
                else if (pbel > pmar && pbel > pcan)
                {
                    GrupoF[0] = "Croacia";
                    GrupoF[1] = "Belgica";
                    gfl2 = pbel;
                }
                else
                {
                    GrupoF[0] = "Croacia";
                    GrupoF[1] = "Canada";
                    gfl2 = pcan;
                }
            }
            else if (pbel > pmar && pbel > pcro && pbel > pcan)
            {
                gfl1 = pbel;
                GrupoF[0] = "Belgica";

                if (pmar > pcro && pmar > pcan)
                {
                    GrupoF[0] = "Belgica";
                    GrupoF[1] = "Marrocos";
                    gfl2 = pmar;
                }
                else if (pcro > pmar && pcro > pcan)
                {
                    GrupoF[0] = "Belgica";
                    GrupoF[1] = "Croacia";
                    gfl2 = pcro;
                }
                else
                {
                    GrupoF[0] = "Belgica";
                    GrupoF[1] = "Canada";
                    gfl2 = pcan;
                }
            }
            else
            {
                gfl1 = pcan;
                GrupoF[0] = "Canada";

                if (pmar > pcro && pmar > pbel)
                {
                    GrupoF[0] = "Canada";
                    GrupoF[1] = "Marrocos";
                    gfl2 = pmar;
                }
                else if (pcro > pmar && pcro > pbel)
                {
                    GrupoF[0] = "Canada";
                    GrupoF[1] = "Croacia";
                    gfl2 = pcro;
                }
                else
                {
                    GrupoF[0] = "Canada";
                    GrupoF[1] = "Belgica";
                    gfl2 = pbel;
                }
            }
            


            
            //Brasil- Suiça- Servia- Camarões
                        
           
            int ggl1 = 0;
            int ggl2 = 0;

            if (pbr > psui && pbr > pcam && pbr > pser)
            {
                ggl1 = pbr;
                GrupoG[0] = "Brasil";

                if (psui > pcam && psui > pser)
                {
                    GrupoG[0] = "Brasil";
                    GrupoG[1] = "Suiça";
                    ggl2 = psui;
                }
                else if (pcam > psui && pcam > pser)
                {
                    GrupoG[0] = "Brasil";
                    GrupoG[1] = "Camarões";
                    ggl2 = pcam;
                }
                else
                {
                    GrupoG[0] = "Brasil";
                    GrupoG[1] = "Servia";
                    ggl2 = pser;
                }
            }
            else if (psui > pbr && psui > pcam && psui > pser)
            {
                ggl1 = psui;
                GrupoG[0] = "Suiça";

                if (pbr > pcam && pbr > pser)
                {
                    GrupoG[0] = "Suiça";
                    GrupoG[1] = "Brasil";
                    ggl2 = pbr;
                }
                else if (pcam > pbr && pcam > pser)
                {
                    GrupoG[0] = "Suiça";
                    GrupoG[1] = "Camarões";
                    ggl2 = pcam;
                }
                else
                {
                    GrupoG[0] = "Suiça";
                    GrupoG[1] = "Servia";
                    ggl2 = pser;
                }
            }
            else if (pcam > pbr && pcam > psui && pcam > pser)
            {
                ggl1 = pcam;
                GrupoG[0] = "Camarões";

                if (pbr > psui && pbr > pser)
                {
                    GrupoG[0] = "Camarões";
                    GrupoG[1] = "Brasil";
                    ggl2 = pbr;
                }
                else if (psui > pbr && psui > pser)
                {
                    GrupoG[0] = "Camarões";
                    GrupoG[1] = "Suiça";
                    ggl2 = psui;
                }
                else
                {
                    GrupoG[0] = "Camarões";
                    GrupoG[1] = "Servia";
                    ggl2 = pser;
                }
            }
            else
            {
                ggl1 = pser;
                GrupoG[0] = "Servia";

                if (pbr > psui && pbr > pcam)
                {
                    GrupoG[0] = "Servia";
                    GrupoG[1] = "Brasil";
                    ggl2 = pbr;
                }
                else if (psui > pbr && psui > pcam)
                {
                    GrupoG[0] = "Servia";
                    GrupoG[1] = "Suiça";
                    ggl2 = psui;
                }
                else
                {
                    GrupoG[0] = "Servia";
                    GrupoG[1] = "Camarões";
                    ggl2 = pcam;
                }
            }

            

            
            //Coreia do Sul- Portugal- Gana- Uruguai
           
            
            int ghl1 = 0;
            int ghl2 = 0;
            if (pCs > pPt && pCs > pUr && pCs > pAn)
            {
                ghl1 = pCs;
                GrupoH[0] = "Coreia Do Sul";

                if (pPt > pUr && pPt > pAn)
                {
                    GrupoH[0] = "Coreia Do Sul";
                    GrupoH[1] = "Portugal";
                    ghl2 = pPt;
                }
                else if (pUr > pPt && pUr > pAn)
                {
                    GrupoH[0] = "Coreia Do Sul";
                    GrupoH[1] = "Uruguai";
                    ghl2 = pUr;
                }
                else
                {
                    GrupoH[0] = "Coreia Do Sul";
                    GrupoH[1] = "Gana";
                    ghl2 = pAn;
                }
            }
            else if (pPt > pCs && pPt > pUr && pPt > pAn)
            {
                ghl1 = pPt;
                GrupoH[0] = "Portugal";

                if (pCs > pUr && pCs > pAn)
                {
                    GrupoH[0] = "Portugal";
                    GrupoH[1] = "Coreia do Sul";
                    ghl2 = pCs;
                }
                else if (pUr > pCs && pUr > pAn)
                {
                    GrupoH[0] = "Portugal";
                    GrupoH[1] = "Uruguai";
                    ghl2 = pUr;
                }
                else
                {
                    GrupoH[0] = "Portugal";
                    GrupoH[1] = "Gana";
                    ghl2 = pAn;
                }
            }
            else if (pUr > pCs && pUr > pPt && pUr > pAn)
            {
                ghl1 = pUr;
                GrupoH[0] = "Uruguai";

                if (pCs > pPt && pCs > pAn)
                {
                    GrupoH[0] = "Uruguai";
                    GrupoH[1] = "Coreia do Sul";
                    ghl2 = pCs;
                }
                else if (pPt > pCs && pPt > pAn)
                {
                    GrupoH[0] = "Uruguai";
                    GrupoH[1] = "Portugal";
                    ghl2 = pPt;
                }
                else
                {
                    GrupoH[0] = "Uruguai";
                    GrupoH[1] = "Gana";
                    ghl2 = pAn;
                }
            }
            else
            {
                ghl1 = pAn;
                GrupoH[0] = "Gana";

                if (pCs > pPt && pCs > pUr)
                {
                    GrupoH[0] = "Gana";
                    GrupoH[1] = "Coreia do Sul";
                    ghl2 = pCs;
                }
                else if (pPt > pCs && pPt > pUr)
                {
                    GrupoH[0] = "Gana";
                    GrupoH[1] = "Portugal";
                    ghl2 = pPt;
                }
                else
                {
                    GrupoH[0] = "Gana";
                    GrupoH[1] = "Uruguai";
                    ghl2 = pUr;
                }
            }



            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("\n\n\n\nEquipas que passaram para os OITAVOS de FINAL:");
            Console.ResetColor();


            Console.WriteLine("\nEquipa:" + GrupoA[1] + "");
            Console.WriteLine("Equipa:" + GrupoB[0] + "");
            Console.WriteLine("Equipa:" + GrupoC[1] + "");
            Console.WriteLine("Equipa:" + GrupoD[0] + "");
            Console.WriteLine("Equipa:" + GrupoE[1] + "");
            Console.WriteLine("Equipa:" + GrupoF[0] + "");
            Console.WriteLine("Equipa:" + GrupoG[1] + "");
            Console.WriteLine("Equipa:" + GrupoH[0] + "");

            
                
            Console.WriteLine("\n\nClica na tecla ENTER para ir para as Eliminatorias! (OITAVOS DE FINAL)");
            Console.ReadKey();
            Console.Clear();




           
            Console.ForegroundColor = ConsoleColor.DarkMagenta;
            Console.WriteLine ("<<<<<<<<<<<<<<<<<<<| OITAVOS DE FINAL: |>>>>>>>>>>>>>>>>>>>>>>>");
            Console.ResetColor();

           
            Console.WriteLine("\n\n>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("Oitavos de final 1º Rodada:");
            Console.ResetColor();
            
            
            Random rnd777 = new Random();

            int equipa1 = rnd777.Next(0, 6);

            Random rnd778 = new Random();

            int equipa2 = rnd778.Next(0, 3);


            Console.WriteLine(GrupoA[1] + ": " + equipa1 + " golos");
            Console.WriteLine("VS");
            Console.WriteLine(GrupoB[0] + ": " + equipa2 + " golos");
            
            if (equipa1 > equipa2)
            {
                Console.Write("Resultado: "); 
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoA[1] + " Venceu!\n");
                jQuartosfinal1 = GrupoA[1];
            }
            else if (equipa1 == equipa2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write(" Empate!\n");

                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nAs duas equipas empataram pois terão que ir a penaltis!");

                Random rnd9991 = new Random();

                int penaltis = rnd9991.Next(0, 2);


                if (penaltis == 0)
                {

                    Console.WriteLine(GrupoA[1] + " venceu as penalidades, passou à próxima fase!");
                    jQuartosfinal1 = GrupoA[1];
                }
                else
                {

                    Console.WriteLine(GrupoB[0] + " venceu as penalidades, passou à próxima fase!");
                    jQuartosfinal1 = GrupoB[0];
                }


            }
            else if (equipa1 < equipa2)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoB[0] + " Venceu!\n");
                jQuartosfinal2 = GrupoB[0];
            }

            Console.ResetColor();
             Console.WriteLine(">>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");




            Console.WriteLine("\n\n>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("Oitavos de final 2º Rodada:");
            Console.ResetColor();
            
            
            
            Random rnd779 = new Random();

            int equipa3 = rnd779.Next(0, 6);

            Random rnd780 = new Random();

            int equipa4 = rnd780.Next(0, 4);


            Console.WriteLine(GrupoC[1] + ": " + equipa3 + " golos");
            Console.WriteLine("VS");
            Console.WriteLine(GrupoD[0] + ": " + equipa4 + " golos");

            if (equipa3 > equipa4)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoC[1] + " Venceu!\n");
                jQuartosfinal3 = GrupoC[1];
            }
            else if (equipa3 == equipa4)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write(" Empate!\n");

                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nAs duas equipas empataram pois terão que ir a penaltis!");

                Random rnd9992 = new Random();

                int penaltis2 = rnd9992.Next(0, 2);


                if (penaltis2 == 0)
                {

                    Console.WriteLine(GrupoC[1] + " venceu as penalidades, passou à próxima fase!");
                    jQuartosfinal2 = GrupoC[1];
                }
                else
                {

                    Console.WriteLine(GrupoD[0] + " venceu as penalidades, passou à próxima fase!");
                    jQuartosfinal2 = GrupoD[0];
                }



            }
            else if (equipa3 < equipa4)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoD[0] + " Venceu!\n");
                jQuartosfinal4 = GrupoD[0];
            }
            Console.ResetColor();
            Console.WriteLine(">>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");






            Console.WriteLine("\n\n>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("Oitavos de final 3º Rodada:");
            Console.ResetColor();
            
            Random rnd781 = new Random();

            int equipa5 = rnd781.Next(0, 7);

            Random rnd782 = new Random();

            int equipa6 = rnd782.Next(0, 5);


            Console.WriteLine(GrupoE[1] + ": " + equipa5 + " golos");
            Console.WriteLine("VS");
            Console.WriteLine(GrupoF[0] + ": " + equipa6 + " golos");

            if (equipa5 > equipa6)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoE[1] + " Venceu!\n");
                jQuartosfinal5 = GrupoE[1];
            }
            else if (equipa5 == equipa6)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write(" Empate!\n");

                
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nAs duas equipas empataram pois terão que ir a penaltis!");

                Random rnd9993 = new Random();

                int penaltis = rnd9993.Next(0, 2);


                if (penaltis == 0)
                {

                    Console.WriteLine(GrupoE[1] + " venceu as penalidades, passou à próxima fase!");
                    jQuartosfinal3 = GrupoE[1];
                }
                else
                {

                    Console.WriteLine(GrupoF[0] + " venceu as penalidades, passou à próxima fase!");
                    jQuartosfinal3 = GrupoF[0];
                }


            }
            else if (equipa5 < equipa6)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoF[0] + " Venceu!\n");
                jQuartosfinal6 = GrupoF[0];
            }
            Console.ResetColor();
            Console.WriteLine(">>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");




            Console.WriteLine("\n\n>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("Oitavos de final 4º Rodada:");
            Console.ResetColor();

            Random rnd783 = new Random();

            int equipa7 = rnd783.Next(0, 7);

            Random rnd784 = new Random();

            int equipa8 = rnd784.Next(0, 5);


            Console.WriteLine(GrupoG[1] + ": " + equipa7 + " golos");
            Console.WriteLine("VS");
            Console.WriteLine(GrupoH[0] + ": " + equipa8 + " golos");

            if (equipa7 > equipa8)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoG[1] + " Venceu!\n");
                jQuartosfinal7 = GrupoG[1];
            }
            else if (equipa7 == equipa8)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write(" Empate!\n");


                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nAs duas equipas empataram pois terão que ir a penaltis!");

                Random rnd9994 = new Random();

                int penaltis3 = rnd9994.Next(0, 2);


                if (penaltis3 == 0)
                {

                    Console.WriteLine(GrupoG[1] + " venceu as penalidades, passou à próxima fase!");
                    jQuartosfinal4 = GrupoG[1];
                }
                else
                {

                    Console.WriteLine(GrupoH[0] + " venceu as penalidades, passou à próxima fase!");
                    jQuartosfinal4 = GrupoH[0];
                }




            }
            else if (equipa7 < equipa8)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoH[0] + " Venceu!\n");
                jQuartosfinal8 = GrupoH[0];
            }
            Console.ResetColor();
            Console.WriteLine(">>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");



            //CONTRARIO


            Console.WriteLine("\n\n>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("Oitavos de final 5º Rodada:");
            Console.ResetColor();


            Random rnd400 = new Random();

            int equipa9 = rnd400.Next(0, 6);

            Random rnd401 = new Random();

            int equipa10 = rnd401.Next(0, 3);


            Console.WriteLine(GrupoB[1] + ": " + equipa9 + " golos");
            Console.WriteLine("VS");
            Console.WriteLine(GrupoA[0] + ": " + equipa10 + " golos");

            if (equipa9 > equipa10)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoB[1] + " Venceu!\n");
                jQuartosfinal1 = GrupoB[1];
            }
            else if (equipa9 == equipa10)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write(" Empate!\n");

                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nAs duas equipas empataram pois terão que ir a penaltis!");

                Random rnd9991 = new Random();

                int penaltis = rnd9991.Next(0, 2);


                if (penaltis == 0)
                {

                    Console.WriteLine(GrupoB[1] + " venceu as penalidades, passou à próxima fase!");
                    jQuartosfinal1 = GrupoB[1];
                }
                else
                {

                    Console.WriteLine(GrupoA[0] + " venceu as penalidades, passou à próxima fase!");
                    jQuartosfinal1 = GrupoA[0];
                }


            }
            else if (equipa9 < equipa10)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoA[0] + " Venceu!\n");
                jQuartosfinal2 = GrupoA[0];
            }

            Console.ResetColor();
            Console.WriteLine(">>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");




            Console.WriteLine("\n\n>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("Oitavos de final 6º Rodada:");
            Console.ResetColor();



            Random rnd403 = new Random();

            int equipa11 = rnd403.Next(0, 2);

            Random rnd404 = new Random();

            int equipa12 = rnd404.Next(0, 7);


            Console.WriteLine(GrupoD[1] + ": " + equipa11 + " golos");
            Console.WriteLine("VS");
            Console.WriteLine(GrupoC[0] + ": " + equipa12 + " golos");

            if (equipa11 > equipa12)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoD[1] + " Venceu!\n");
                jQuartosfinal3 = GrupoD[1];
            }
            else if (equipa11 == equipa12)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write(" Empate!\n");

                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nAs duas equipas empataram pois terão que ir a penaltis!");

                Random rnd9992 = new Random();

                int penaltis2 = rnd9992.Next(0, 2);


                if (penaltis2 == 0)
                {

                    Console.WriteLine(GrupoD[1] + " venceu as penalidades, passou à próxima fase!");
                    jQuartosfinal2 = GrupoD[1];
                }
                else
                {

                    Console.WriteLine(GrupoC[0] + " venceu as penalidades, passou à próxima fase!");
                    jQuartosfinal2 = GrupoC[0];
                }



            }
            else if (equipa11 < equipa12)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoC[0] + " Venceu!\n");
                jQuartosfinal4 = GrupoC[0];
            }
            Console.ResetColor();
            Console.WriteLine(">>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");






            Console.WriteLine("\n\n>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("Oitavos de final 7º Rodada:");
            Console.ResetColor();

            Random rnd405 = new Random();

            int equipa13 = rnd405.Next(0, 7);

            Random rnd406 = new Random();

            int equipa14 = rnd405.Next(0, 5);


            Console.WriteLine(GrupoF[1] + ": " + equipa13 + " golos");
            Console.WriteLine("VS");
            Console.WriteLine(GrupoE[0] + ": " + equipa14 + " golos");

            if (equipa13 > equipa14)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoF[1] + " Venceu!\n");
                jQuartosfinal5 = GrupoF[1];
            }
            else if (equipa13 == equipa14)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write(" Empate!\n");


                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nAs duas equipas empataram pois terão que ir a penaltis!");

                Random rnd9993 = new Random();

                int penaltis = rnd9993.Next(0, 2);


                if (penaltis == 0)
                {

                    Console.WriteLine(GrupoF[1] + " venceu as penalidades, passou à próxima fase!");
                    jQuartosfinal3 = GrupoF[1];
                }
                else
                {

                    Console.WriteLine(GrupoE[0] + " venceu as penalidades, passou à próxima fase!");
                    jQuartosfinal3 = GrupoE[0];
                }


            }
            else if (equipa13 < equipa14)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoE[0] + " Venceu!\n");
                jQuartosfinal6 = GrupoE[0];
            }
            Console.ResetColor();
            Console.WriteLine(">>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");




            Console.WriteLine("\n\n>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("Oitavos de final 8º Rodada:");
            Console.ResetColor();

            Random rnd407 = new Random();

            int equipa15 = rnd407.Next(0, 7);

            Random rnd408 = new Random();

            int equipa16 = rnd408.Next(0, 5);


            Console.WriteLine(GrupoH[1] + ": " + equipa15 + " golos");
            Console.WriteLine("VS");
            Console.WriteLine(GrupoG[0] + ": " + equipa16 + " golos");

            if (equipa15 > equipa16)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoH[1] + " Venceu!\n");
                jQuartosfinal7 = GrupoH[1];
            }
            else if (equipa15 == equipa16)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write(" Empate!\n");


                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nAs duas equipas empataram pois terão que ir a penaltis!");

                Random rnd9994 = new Random();

                int penaltis3 = rnd9994.Next(0, 2);


                if (penaltis3 == 0)
                {

                    Console.WriteLine(GrupoH[1] + " venceu as penalidades, passou à próxima fase!");
                    jQuartosfinal4 = GrupoH[1];
                }
                else
                {

                    Console.WriteLine(GrupoG[0] + " venceu as penalidades, passou à próxima fase!");
                    jQuartosfinal4 = GrupoG[0];
                }




            }
            else if (equipa15 < equipa16)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoG[0] + " Venceu!\n");
                jQuartosfinal8 = GrupoG[0];
            }
            Console.ResetColor();
            Console.WriteLine(">>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");





            Console.WriteLine("\n\nClica na tecla ENTER para ir para as Eliminatorias! (QARTOS DE FINAL)");
            Console.ReadKey();
            Console.Clear();





            Console.ForegroundColor = ConsoleColor.DarkMagenta;
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<| QUARTOS DE FINAL: |>>>>>>>>>>>>>>>>>>>>>>>");
            Console.ResetColor();


            Console.WriteLine("\n\n>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("Quartos de final 1º Rodada:");
            Console.ResetColor();


            Random rnd785 = new Random();

            int equipa17 = rnd785.Next(0, 8);

            Random rnd786 = new Random();

            int equipa18 = rnd786.Next(0, 4);


            Console.WriteLine(jQuartosfinal1 + ": " + equipa17 + " golos");
            Console.WriteLine("VS");
            Console.WriteLine(jQuartosfinal2 + ": " + equipa18 + " golos");

            if (equipa17 > equipa18)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jQuartosfinal1 + " Venceu!\n");
                jSemifinal1 = jQuartosfinal1;
            }
            else if (equipa17 == equipa18)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write(" Empate!\n");



                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nAs duas equipas empataram pois terão que ir a penaltis!");

                Random rnd9995 = new Random();

                int penaltis4 = rnd9995.Next(0, 2);


                if (penaltis4 == 0)
                {

                    Console.WriteLine(jQuartosfinal1 + " venceu as penalidades, passou à próxima fase!");
                    jSemifinal1 = jQuartosfinal1; 

                }
                else
                {

                    Console.WriteLine(jQuartosfinal2 + " venceu as penalidades, passou à próxima fase!");
                    jSemifinal1 = jQuartosfinal2;
                }


            }
            else if (equipa17 < equipa18)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jQuartosfinal2 + " Venceu!\n");
                jSemifinal1 = jQuartosfinal2;
            }

            Console.ResetColor();
            Console.WriteLine(">>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");




            Console.WriteLine("\n\n>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("Quartos de final 2º Rodada:");
            Console.ResetColor();



            Random rnd787 = new Random();

            int equipa19 = rnd787.Next(0, 7);

            Random rnd788 = new Random();

            int equipa20 = rnd788.Next(0, 3);


            Console.WriteLine(jQuartosfinal3 + ": " + equipa19 + " golos");
            Console.WriteLine("VS");
            Console.WriteLine(jQuartosfinal4 + ": " + equipa20 + " golos");

            if (equipa19 > equipa20)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jQuartosfinal3 + " Venceu!\n");
                jSemifinal2 = jQuartosfinal3;
            }
            else if (equipa19 == equipa20)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write(" Empate!\n");


                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nAs duas equipas empataram pois terão que ir a penaltis!");

                Random rnd9996 = new Random();

                int penaltis5 = rnd9996.Next(0, 2);


                if (penaltis5 == 0)
                {

                    Console.WriteLine(jQuartosfinal3 + " venceu as penalidades, passou à próxima fase!");
                    jSemifinal2 = jQuartosfinal3;
                }
                else
                {

                    Console.WriteLine(jQuartosfinal4 + " venceu as penalidades, passou à próxima fase!");
                    jSemifinal2 = jQuartosfinal4;
                }


            }
            else if (equipa19 < equipa20)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jQuartosfinal4 + " Venceu!\n");
                jSemifinal2 = jQuartosfinal4;
            }
            Console.ResetColor();
            Console.WriteLine(">>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");






            Console.WriteLine("\n\n>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("Quartos de final 3º Rodada:");
            Console.ResetColor();

            Random rnd789 = new Random();

            int equipa21 = rnd789.Next(0, 5);

            Random rnd790 = new Random();

            int equipa22 = rnd790.Next(0, 7);


            Console.WriteLine(jQuartosfinal5 + ": " + equipa21 + " golos");
            Console.WriteLine("VS");
            Console.WriteLine(jQuartosfinal6 + ": " + equipa22 + " golos");

            if (equipa21 > equipa22)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jQuartosfinal5 + " Venceu!\n");
                jSemifinal3 = jQuartosfinal5;
            }
            else if (equipa21 == equipa22)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write(" Empate!\n");


                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nAs duas equipas empataram pois terão que ir a penaltis!");

                Random rnd9997 = new Random();

                int penaltis6 = rnd9997.Next(0, 2);


                if (penaltis6 == 0)
                {

                    Console.WriteLine(jQuartosfinal5 + " venceu as penalidades, passou à próxima fase!");
                    jSemifinal3 = jQuartosfinal5;
                }
                else
                {

                    Console.WriteLine(jQuartosfinal6 + " venceu as penalidades, passou à próxima fase!");
                    jSemifinal3 = jQuartosfinal6;
                }

            }
            else if (equipa21 < equipa22)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jQuartosfinal6 + " Venceu!\n");
                jSemifinal3 = jQuartosfinal6;
            }
            Console.ResetColor();
            Console.WriteLine(">>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");




            Console.WriteLine("\n\n>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("Quartos de final 4º Rodada:");
            Console.ResetColor();

            Random rnd791 = new Random();

            int equipa23 = rnd791.Next(0, 7);

            Random rnd792 = new Random();

            int equipa24 = rnd792.Next(0, 5);


            Console.WriteLine(jQuartosfinal7 + ": " + equipa23 + " golos");
            Console.WriteLine("VS");
            Console.WriteLine(jQuartosfinal8 + ": " + equipa24 + " golos");

            if (equipa23 > equipa24)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jQuartosfinal7 + " Venceu!\n");
                jSemifinal4 = jQuartosfinal7;
            }
            else if (equipa23 == equipa24)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write(" Empate!\n");

                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nAs duas equipas empataram pois terão que ir a penaltis!");

                Random rnd9998 = new Random();

                int penaltis7 = rnd9998.Next(0, 2);


                if (penaltis7 == 0)
                {

                    Console.WriteLine(jQuartosfinal7 + " venceu as penalidades, passou à próxima fase!");
                    jSemifinal4 = jQuartosfinal7;
                }
                else
                {

                    Console.WriteLine(jQuartosfinal8 + " venceu as penalidades, passou à próxima fase!");
                    jSemifinal4 = jQuartosfinal8;
                }

            }
            else if (equipa23 < equipa24)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jQuartosfinal8 + " Venceu!\n");
                jSemifinal4 = jQuartosfinal8;
            }
            Console.ResetColor();
            Console.WriteLine(">>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");



            Console.WriteLine("\n\nClica na tecla ENTER para ir para as Eliminatorias! (SEMI FINAIS)");
            Console.ReadKey();
            Console.Clear();







            Console.ForegroundColor = ConsoleColor.DarkMagenta;
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<| SEMI FINAIS: |>>>>>>>>>>>>>>>>>>>>>>>");
            Console.ResetColor();


            Console.WriteLine("\n\n>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("Semi final 1º Rodada:");
            Console.ResetColor();


            Random rnd3000 = new Random();

            int equipa42 = rnd3000.Next(0, 7);

            Random rnd3001 = new Random();

            int equipa43 = rnd3001.Next(0, 4);


            Console.WriteLine(jSemifinal1 + ": " + equipa42 + " golos");
            Console.WriteLine("VS");
            Console.WriteLine(jSemifinal2 + ": " + equipa43 + " golos");

            if (equipa42 > equipa43)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jSemifinal1 + " Venceu!\n");
                jFinal1 = jSemifinal1;
            }
            else if (equipa42 == equipa43)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write(" Empate!\n");

                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nAs duas equipas empataram pois terão que ir a penaltis!");

                Random rnd10000 = new Random();

                int penaltis8 = rnd10000.Next(0, 2);


                if (penaltis8 == 0)
                {

                    Console.WriteLine(jSemifinal1 + " venceu as penalidades, passou à próxima fase!");
                    jFinal1 = jSemifinal1;
                }
                else
                {

                    Console.WriteLine(jSemifinal2 + " venceu as penalidades, passou à próxima fase!");
                    jFinal1 = jSemifinal2;
                }

            }
            else if (equipa42 < equipa43)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jSemifinal2 + " Venceu!\n");
                jFinal1 = jSemifinal2;
            }

            Console.ResetColor();
            Console.WriteLine(">>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");




            Console.WriteLine("\n\n>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("Semi final 2º Rodada:");
            Console.ResetColor();



            Random rnd3002 = new Random();

            int equipa44 = rnd3002.Next(0,7);

            Random rnd3003 = new Random();

            int equipa45 = rnd3003.Next(0, 4);


            Console.WriteLine(jSemifinal3 + ": " + equipa44 + " golos");
            Console.WriteLine("VS");
            Console.WriteLine(jSemifinal4 + ": " + equipa45 + " golos");

            if (equipa44 > equipa45)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jSemifinal2 + " Venceu!\n");
                jFinal1 = jSemifinal2;
            }
            else if (equipa44 == equipa45)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write(" Empate!\n");

                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nAs duas equipas empataram pois terão que ir a penaltis!");

                Random rnd10001 = new Random();

                int penaltis9 = rnd10001.Next(0, 2);


                if (penaltis9 == 0)
                {

                    Console.WriteLine(jSemifinal3 + " venceu as penalidades, passou à próxima fase!");
                    jFinal2 = jSemifinal3;
                }
                else
                {

                    Console.WriteLine(jSemifinal4 + " venceu as penalidades, passou à próxima fase!");
                    jFinal2 = jSemifinal4;
                }

            }
            else if (equipa44 < equipa45)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jSemifinal2 + " Venceu!\n");
                jFinal2 = jSemifinal2;
            }
            Console.ResetColor();
            Console.WriteLine(">>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");


            Console.WriteLine("\n\nClica na tecla ENTER para ir para as Eliminatorias! (FINAIS)");
            Console.ReadKey();
            Console.Clear();








            Console.ForegroundColor = ConsoleColor.DarkMagenta;
            Console.WriteLine("<<<<<<<<<<<<<<<<<<<| FINAIS: |>>>>>>>>>>>>>>>>>>>>>>>");
            Console.ResetColor();


            Console.WriteLine("\n\n>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("Final:");
            Console.ResetColor();


            Random rnd3004 = new Random();

            int equipa46 = rnd3004.Next(0, 7);

            Random rnd3005 = new Random();

            int equipa47 = rnd3005.Next(0, 4);


            Console.WriteLine(jFinal1 + ": " + equipa46 + " golos");
            Console.WriteLine("VS");
            Console.WriteLine(jFinal2 + ": " + equipa47 + " golos");

            if (equipa46 > equipa47)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jFinal1 + " Venceu!\n");
                jVencedor = jFinal1;
            }
            else if (equipa46 == equipa47)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.Write(" Empate!\n");

                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\nAs duas equipas empataram pois terão que ir a penaltis!");

                Random rnd10003 = new Random();

                int penaltis10 = rnd10003.Next(0, 2);


                if (penaltis10 == 0)
                {

                    Console.WriteLine(jFinal1 + " venceu as penalidades, e ganhou o MUNDIAL!");
                    jVencedor = jFinal1;
                }
                else
                {

                    Console.WriteLine(jFinal2 + " venceu as penalidades, e ganhou o MUNDIAL!");
                    jVencedor = jFinal2;
                }

            }
            else if (equipa46 < equipa47)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jFinal2 + " Venceu!\n");
                jVencedor = jFinal2;
            }

            Console.ResetColor();
            Console.WriteLine(">>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<");



            Console.WriteLine("");














            Console.ReadLine();
        }



    }
}
